@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo horario</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'empleado/asistencia', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}

		<div class="form-group">
			<label for="empleado">Empleado</label>
					<select name="fk_empleado" class="form-control">
						@foreach ($empleado as $emp)
						<option value="{{$emp->id}}">{{$emp->nombre}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<label for="fecha">Fecha</label>
			<input type="date" name="fecha" class="form-control" placeholder="Fecha">	
		</div>

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}
		</div>	
	</div>
@endsection