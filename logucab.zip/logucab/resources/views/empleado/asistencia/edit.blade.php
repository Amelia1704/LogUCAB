@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Asistencia: {{ $empleado->nombre }} {{ $empleado->apellido }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::model($asistencia,['method'=>'PATCH', 'route'=>['asistencia.update', $asistencia->codigo]])!!}
		{{Form::token()}}
		<div class="form-group">
			<label for="fecha">Fecha</label>
			<input type="date" name="fecha" required value="{{$asistencia->fecha}}" class="form-control">
		</div>	
	
		<div class="form-group">
			<a href="{{URL::action('AsistenciaController@index')}}"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>		
	</div>
@endsection