@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo horario</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'empleado/horario', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}

		<div class="form-group">
			<label for="empleado">Empleado</label>
					<select name="fk_empleado" class="form-control">
						@foreach ($empleado as $emp)
						<option value="{{$emp->id}}">{{$emp->nombre}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<label for="dia">Lunes:</label>	
		<div class="form-group">
			<label for="hora_entrada1">Hora Entrada</label>
			<input type="text" name="hora_entrada1" class="form-control" placeholder="Hora Entrada">	
		<div class="form-group">
			<label for="hora_salida1">Hora Salida</label>
			<input type="text" name="hora_salida1" class="form-control" placeholder="Hora Salida">	
		</div>
		<div class="form-group">
			<label for="dia">Martes:</label>	
		<div class="form-group">
			<label for="hora_entrada2">Hora Entrada</label>
			<input type="text" name="hora_entrada2" class="form-control" placeholder="Hora Entrada">	
		<div class="form-group">
			<label for="hora_salida2">Hora Salida</label>
			<input type="text" name="hora_salida2" class="form-control" placeholder="Hora Salida">	
		</div>
		<div class="form-group">
			<label for="dia">Miércoles:</label>	
		<div class="form-group">
			<label for="hora_entrada3">Hora Entrada</label>
			<input type="text" name="hora_entrada3" class="form-control" placeholder="Hora Entrada">	
		<div class="form-group">
			<label for="hora_salida3">Hora Salida</label>
			<input type="text" name="hora_salida3" class="form-control" placeholder="Hora Salida">	
		</div>
		<div class="form-group">
			<label for="dia">Jueves:</label>	
		<div class="form-group">
			<label for="hora_entrada4">Hora Entrada</label>
			<input type="text" name="hora_entrada4" class="form-control" placeholder="Hora Entrada">	
		<div class="form-group">
			<label for="hora_salida4">Hora Salida</label>
			<input type="text" name="hora_salida4" class="form-control" placeholder="Hora Salida">	
		</div>
		<div class="form-group">
			<label for="dia">Viernes:</label>	
		<div class="form-group">
			<label for="hora_entrada5">Hora Entrada</label>
			<input type="text" name="hora_entrada5" class="form-control" placeholder="Hora Entrada">	
		<div class="form-group">
			<label for="hora_salida5">Hora Salida</label>
			<input type="text" name="hora_salida5" class="form-control" placeholder="Hora Salida">	
		</div> 

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection