@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Horarios LogUCAB <a href="create"><button class="btn btn-success">Nuevo</button></a></h3>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>COD</td>
					<td>Día</td>
					<td>Hora de Entrada</td>
					<td>Hora de Salida</td>
				</thead>

				@foreach ($horarios as $hor)
				<tr>
					<td>{{ $hor->codigo }}</td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td>{{ $hor->dia }}</td>
					<td>{{ $hor->hora_entrada }}</td>
					<td>{{ $hor->hora_salida }}</td>

						<td><a href="{{URL::action('HorarioController@edit',$hor->codigo)}}"><button class="btn btn-info">Editar</button></a></td>
					</td>
				</tr>
				@endforeach
			</table>
		</div>
		{{$horarios->render()}}
	</div>
</div>

@endsection