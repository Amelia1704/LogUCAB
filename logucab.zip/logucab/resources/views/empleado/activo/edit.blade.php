@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Empleado: {{ $empleado->nombre }} {{ $empleado->apellido }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::model($empleado,['method'=>'PATCH', 'route'=>['activo.update', $empleado->id]])!!}
		{{Form::token()}}
		<div class="form-group">
			<label for="cedula">Cédula</label>
			<input type="text" name="cedula" required value="{{$empleado->cedula}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre"required value="{{$empleado->nombre}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="apellido">Apellido</label>
			<input type="text" name="apellido"required value="{{$empleado->apellido}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="telefono">Número de Teléfono</label>
			@foreach ($telefono as $t)
			<input type="text" name="telefono" required value="{{$t->numero}}" class="form-control">
			@endforeach
		</div>
		<div class="form-group">
			<label for="email_personal">Email Personal</label>
			<input type="text" name="email_personal"required value="{{$empleado->email_personal}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="email_empresa">Email Empresa</label>
			<input type="text" name="email_empresa"required value="{{$empleado->email_empresa}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_nac">Fecha de nacimiento</label>
			<input type="text" name="fecha_nac" required value="{{$empleado->fecha_nac}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="nivel_academico">Nivel Académico</label>
			<input type="text" name="nivel_academico"required value="{{$empleado->nivel_academico}}" class="form-control">
		</div><div class="form-group">
			<label for="profesion">Profesión</label>
			<input type="text" name="profesion"required value="{{$empleado->profesion}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="estado_civil">Estado civil</label>
			<input type="text" name="estado_civil"required value="{{$empleado->estado_civil}}" class="form-control">
		</div>		
		<div class="form-group">
			<label for="numero_hijos">Número de Hijos</label>
			<input type="text" name="numero_hijos" required value="{{$empleado->numero_hijos}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="salario">Salario</label>
			<input type="text" name="salario" required value="{{$empleado->salario}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_ingreso">Fecha Ingreso</label>
			<input type="text" name="fecha_ingreso" required value="{{$empleado->fecha_ingreso}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="activo">Activo</label>
			<input type="text" name="activo"required value="{{$empleado->activo}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_egreso">Fecha de Egreso</label>
			<input type="text" name="fecha_egreso" class="form-control">
		</div>
		<div class="form-group">
			<label for="fk_lugar">Direccion</label>
					<select name="fk_lugar" class="form-control">
						@foreach ($lugar as $lug)
						@if ($lug->codigo==$empleado->fk_lugar)
						<option value="{{$lug->codigo}}" selected>{{$lug->nombre}}</option>@else
						<option value="{{$lug->codigo}}">{{$lug->nombre}}</option>
						@endif
						@endforeach
					</select>	
		</div>	
		<div class="form-group">
			<label for="fk_sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						@foreach ($sucursal as $suc)
						@if ($suc->codigo==$empleado->fk_sucursal)
						<option value="{{$suc->codigo}}" selected>{{$suc->nombre}}</option>@else
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endif
						@endforeach
					</select>	
		</div>
		<div class="form-group">
			<label for="zona">Zona</label>
					<select name="zona" class="form-control">
						@foreach ($zona as $z)
						<option value="{{$z->codigo}}" selected>{{$z->tipo}}</option>
						@endforeach
					</select>	
		</div>

		<div class="form-group">
			<a href="{{URL::action('EmpleadoController@index')}}"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>		
	</div>
@endsection