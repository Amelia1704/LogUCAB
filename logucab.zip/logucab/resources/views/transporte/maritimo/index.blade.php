@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Transportes Marítimos <a href="maritimo/create"><button class="btn btn-success">Agregar</button></a></h3>
	@include('transporte.maritimo.search')
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>COD</center></td>
					<td><center>Capacidad carga (m2)</center></td>
					<td><center>Serial motor</center></td>
					<td><center>Matrícula</center></td>
					<td><center>Marca</center></td>
					<td><center>Modelo</center></td>
					<td><center>Fecha Vehículo</center></td>
					<td><center>Peso</center></td>
					<td><center>Descripcion</center></td>
					<td><center>Sucursal</center></td>

				</thead>

				@foreach ($maritimos as $maritimo)
				<tr>
					<td>{{ $maritimo->codigo }}</td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td>{{ $maritimo->capacidad_carga }}</td>
					<td>{{ $maritimo->serial_motor }}</td>
					<td><center>{{ $maritimo->matricula }}</center></td>
					<td>{{ $maritimo->marca }}</td>
					<td>{{ $maritimo->modelo }}</td>
					<td>{{ $maritimo->fecha_vehiculo }}</td>
					<td>{{ $maritimo->peso }}</td>
					<td>{{ $maritimo->descripcion }}</td>
					<td>{{ $maritimo->sucursal }}</td>
					<td>
						<td><a href="{{URL::action('MaritimoController@edit',$maritimo->codigo)}}"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-{{$maritimo->codigo}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a></td>
					</td>
				</tr>
				@include('transporte.maritimo.modal')
				@endforeach
			</table>
		</div>
		{{$maritimos->render()}}

			<h4>Transportes mas utilizados</h2>
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>Numero de veces utilizado</td>
					<td>Codigo del transporte</td>
				</thead>

				@foreach ($usados as $us)
				<tr>
					<td>{{ $us->numero }}</td>
					<td>{{ $us->codigo_del_transporte }}</td>
				</tr>
				@endforeach
			</table>

	</div>
</div>

@endsection