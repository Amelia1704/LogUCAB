@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar un nuevo Barco</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'transporte/maritimo', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}


		</div>	
		<div class="form-group">
			<label for="capacidad_carga">Capacidad carga (m2)</label>
			<input type="text" name="capacidad_carga" class="form-control" placeholder="Capacidad carga">	
		</div>
		<div class="form-group">
			<label for="serial_motor">Serial motor</label>
			<input type="text" name="serial_motor" class="form-control" placeholder="Serial motor">	
		</div>	
		<div class="form-group">
			<label for="matricula">Matrícula</label>
			<input type="text" name="matricula" class="form-control" placeholder="Matricula">	
		</div>	
		<div class="form-group">
			<label for="marca">Marca</label>
			<input type="text" name="marca" class="form-control" placeholder="Marca">	
		</div>	
		<div class="form-group">
			<label for="modelo">Modelo</label>
			<input type="text" name="modelo" class="form-control" placeholder="Modelo">	
		</div>		
		<div class="form-group">
			<label for="fecha_vehiculo">Fecha Vehículo</label>
			<input type="date" name="fecha_vehiculo" class="form-control" placeholder="Fecha vehiculo">	
		</div>
		<div class="form-group">
			<label for="peso">Peso</label>
			<input type="text" name="peso" class="form-control" placeholder="peso">	
		</div>	
		<div class="form-group">
			<label for="descripcion">Descripcion</label>
			<input type="text" name="descripcion" class="form-control" placeholder="descripcion">	
		</div>	
		<div class="form-group">
			<label for="sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						@foreach ($sucursal as $suc)
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endforeach
					</select>					
		</div>	

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection