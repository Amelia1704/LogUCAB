@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Transportes Aéreos <a href="aereo/create"><button class="btn btn-success">Agregar</button></a></h3>
	@include('transporte.aereo.search')
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>COD</center></td>
					<td><center>Capacidad carga (m2)</center></td>
					<td><center>Serial motor</center></td>
					<td><center>Matrícula</center></td>
					<td><center>Marca</center></td>
					<td><center>Modelo</center></td>
					<td><center>Fecha Vehículo</center></td>
					<td><center>Longitud</center></td>
					<td><center>Envergadura</center></td>
					<td><center>Área</center></td>
					<td><center>Altura</center></td>
					<td><center>Ancho Cabina</center></td>
					<td><center>Diametro Fuselaje</center></td>
					<td><center>Peso vacío</center></td>
					<td><center>Peso máximo</center></td>
					<td><center>Carrera despeje</center></td>
					<td><center>Velocidad máxima</center></td>
					<td><center>Capacidad combustible</center></td>
					<td><center>Cantidad motores</center></td>
					<td><center>Sucursal</center></td>

				</thead>

				@foreach ($aereos as $aereo)
				<tr>
					<td>{{ $aereo->codigo }}</td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td>{{ $aereo->capacidad_carga }}</td>
					<td>{{ $aereo->serial_motor }}</td>
					<td><center>{{ $aereo->matricula }}</center></td>
					<td>{{ $aereo->marca }}</td>
					<td>{{ $aereo->modelo }}</td>
					<td>{{ $aereo->fecha_vehiculo }}</td>
					<td>{{ $aereo->longitud }}</td>
					<td>{{ $aereo->envergadura }}</td>
					<td>{{ $aereo->area }}</td>
					<td>{{ $aereo->altura }}</td>
					<td>{{ $aereo->ancho_cabina }}</td>
					<td>{{ $aereo->diametro_fuselaje }}</td>
					<td>{{ $aereo->peso_vacio }}</td>
					<td>{{ $aereo->peso_maximo }}</td>
					<td>{{ $aereo->carrera_despeje }}</td>
					<td>{{ $aereo->velocidad_maxima }}</td>
					<td>{{ $aereo->capacidad_combustible }}</td>
					<td>{{ $aereo->cantidad_motor }}</td>
					<td>{{ $aereo->sucursal }}</td>
					<td>
						<td><a href="{{URL::action('AereoController@edit',$aereo->codigo)}}"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-{{$aereo->codigo}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a></td>
					</td>
				</tr>
				@include('transporte.aereo.modal')
				@endforeach
			</table>
		</div>
		{{$aereos->render()}}
	</div>
</div>

@endsection