@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Envío: {{ $envio->numero }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::model($envio,['method'=>'PATCH', 'route'=>['enviar.update', $envio->numero]])!!}
		{{Form::token()}}
		<div class="form-group">
			<label for="nombre">Nombre de la persona que recibe</label>
			<input type="text" name="nombre_recibe"required value="{{$envio->nombre_recibe}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="apellido">Apellido de la persona que recibe</label>
			<input type="text" name="apellido_recibe"required value="{{$envio->apellido_recibe}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="email">Email de la persona que recibe</label>
			<input type="text" name="email_recibe" required value="{{$envio->email_recibe}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="telefono">Teléfono de la persona que recibe</label>
			@foreach ($telefono as $t)
			<input type="text" name="telefono" required value="{{$t->numero}}" class="form-control">
			@endforeach
		</div>	
		

		<div class="form-group">
			<a href="{{URL::action('EnvioController@index')}}"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>		
	</div>
@endsection