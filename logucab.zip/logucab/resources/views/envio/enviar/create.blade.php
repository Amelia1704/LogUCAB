@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo envío</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'envio/enviar', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}

		<div class="form-group">
		<label for="paquete">Enviando Paquete</label>
			<select name="fk_paquete" class="form-control">
			<option value="{{$paquete->codigo}}">{{$paquete->codigo}}</option>
		</select>					
		</div>
		<div class="form-group">
			<label for="cliente_envia">Cliente que envía</label>
					<select name="fk_cliente_envia" class="form-control">
						@foreach ($cliente as $cli)
						<option value="{{$cli->id}}">{{$cli->nombre}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<label for="nombre_recibe">Nombre de la persona que recibe</label>
			<input type="text" name="nombre_recibe" class="form-control" placeholder="Nombre">	
		</div>
		<div class="form-group">
			<label for="apellido_recibe">Apellido de la persona que recibe</label>
			<input type="text" name="apellido_recibe" class="form-control" placeholder="Apellido">	
		</div>
		<div class="form-group">
			<label for="email_recibe">Email de la persona que recibe</label>
			<input type="text" name="email_recibe" class="form-control" placeholder="Email">	
		</div>
		<div class="form-group">
			<label for="telefono">Telefono</label>
			<input type="text" name="telefono" class="form-control" placeholder="+58">	
		</div>			
		<div class="form-group">
			<label for="tipoenvio">Tipo de Envío</label>
			<select name="fk_tipoenvio" class="form-control">
				<option value="1">Terrestre</option>
				<option value="2">Marítimo</option>
				<option value="3">Aéreo</option>
			</select>	
		</div>
		<div class="form-group">
			<label for="ruta">Rutas</label>
					<select name="fk_ruta" class="form-control">
						@foreach ($ruta as $r)
						<option value="{{$r->id}}">{{$r->origen}}--->{{$r->destino}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection