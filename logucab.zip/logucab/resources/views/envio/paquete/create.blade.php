@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar paquete a enviar</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'envio/paquete', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}


		</div>	
		<div class="form-group">
			<label for="peso">Peso (KG)</label>
			<input type="text" name="peso" class="form-control" placeholder="Peso">	
		</div>
		<div class="form-group">
			<label for="profundidad">Profundidad</label>
			<input type="text" name="profundidad" class="form-control" placeholder="Profundidad">	
		</div>	
		<div class="form-group">
			<label for="ancho">Ancho</label>
			<input type="text" name="ancho" class="form-control" placeholder="Ancho">	
		</div>	
		<div class="form-group">
			<label for="alto">Alto</label>
			<input type="text" name="alto" class="form-control" placeholder="Alto">	
		</div>	
		<div class="form-group">
			<label for="tipo">Tipo de paquete</label>
					<select name="fk_tipopaquete" class="form-control">
						@foreach ($tipo as $tipo)
						<option value="{{$tipo->codigo}}">{{$tipo->nombre}}</option>
						@endforeach
					</select>					
		</div>	

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection