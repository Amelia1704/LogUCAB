@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Tus paquetes <a href="paquete/create"><button class="btn btn-success">Agregar</button></a></h3>
	@include('envio.paquete.search')
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>CODIGO</center></td>
					<td><center>Peso</center></td>
					<td><center>Largo (KG)</center></td>
					<td><center>Ancho</center></td>
					<td><center>Alto</center></td>
					<td><center>Tipo del paquete</center></td>

				</thead>

				@foreach ($paquetes as $paquete)
				<tr>
					<td><center>{{ $paquete->codigo }}</center></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><center>{{ $paquete->peso }}</center></td>
					<td><center>{{ $paquete->largo }}</center></td>
					<td><center>{{ $paquete->ancho }}</center></td>
					<td><center>{{ $paquete->alto }}</center></td>
					<td><center>{{ $paquete->tipo }}</center></td>
					<td>
						<td><a href="{{URL::action('PaqueteController@edit',$paquete->codigo)}}" class="btn btn-default btn-lg"><span class="glyphicon glyphicon-pencil"></span></a></td>
						<td><a href="#" class="btn btn-warning btn-lg">
    				    <span class="glyphicon glyphicon-envelope"></span></a></td>
					</td>

				</tr>
				@endforeach
			</table>
		</div>
		{{$paquetes->render()}}
	</div>
</div>

@endsection