@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Cliente LVIP: {{ $cliente->id }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel='stylesheet' href="{{asset('https://fonts.googleapis.com/css?family=Roboto+Condensed')}}">
  <link rel="stylesheet" href="{{asset('css1/style.css')}}">

  <div class="contact-area">
  <div class="contact">
    <main>
      <section>
        <div class="content">
          <img src="{{asset('img/Logo.png')}}" height="70px" alt="Profile Image">

          <aside>
            <h1>Membresía L-VIP</h1>
					<?php  
        				$contar = DB::table('cliente as c')
                        ->where('c.l_vip', '=', 'Si')
                        ->count();	
                     ?>					
                        @for ($x = 1; $x < $contar; $x++)
						@endfor			
            <h1>ID:{{$sucursal->codigo}}-{{$cliente->cedula}}-00{{$x}}</h1>
            <p>Nombre: {{ $cliente->nombre }}</p>
            <p>Apellido: {{ $cliente->apellido }}</p>
            <p>Cedula: {{ $cliente->cedula }}</p>
          </aside>
          
          <button>
            <span>Carnet</span>
            
            <svg xmlns="" width="48" height="48" viewBox="0 0 48 48"> <g class="nc-icon-wrapper" fill="#444444"> <path d="M14.83 30.83L24 21.66l9.17 9.17L36 28 24 16 12 28z"></path> </g> </svg>
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection