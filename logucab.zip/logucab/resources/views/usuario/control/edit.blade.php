@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Usuario: {{ $usuario->nombre }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::model($usuario,['method'=>'PATCH', 'route'=>['control.update', $usuario->codigo]])!!}
		{{Form::token()}}
		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre"required value="{{$usuario->nombre}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="contraseña">Contraseña</label>
			<input type="text" name="contraseña"required value="{{$usuario->contraseña}}" class="form-control">
		</div>	
		<div class="form-group">
			<label for="fk_rol">Rol</label>
					<select name="fk_rol" class="form-control">
						@foreach ($rol as $r)
						@if ($r->codigo==$usuario->fk_rol)
						<option value="{{$r->codigo}}" selected>{{$r->tipo}}</option>@else
						<option value="{{$r->codigo}}">{{$r->tipo}}</option>
						@endif
						@endforeach
					</select>	
		</div>

		<div class="form-group">
			<a href="{{URL::action('SucursalController@index')}}"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>		
	</div>
@endsection