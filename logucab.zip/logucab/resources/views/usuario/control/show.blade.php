@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo usuario</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'usuario/control/storedos', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}

		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre" class="form-control" placeholder="Nombre">	
		</div>	
		<div class="form-group">
			<label for="contraseña">Contraseña</label>
			<input type="text" name="contraseña" class="form-control" placeholder="Contraseña">
		</div>
		<div class="form-group">
			<label for="empleado">Empleado</label>
					<select name="fk_empleado" class="form-control">
						@foreach ($empleado as $e)
						<option value="{{$e->id}}">{{$e->nombre}} - {{$e->cedula}}</option>
						@endforeach
					</select>					
		</div>		
		<div class="form-group">
			<label for="rol">Rol</label>
					<select name="fk_rol" class="form-control">
						@foreach ($rol as $r)
						<option value="{{$r->codigo}}">{{$r->tipo}}</option>
						@endforeach
					</select>					
		</div>	
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection