@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Usuarios <a href="control/create"><button class="btn btn-success">Agregar usuario para cliente</button> <a href="control/show"><button class="btn btn-success">Agregar usuario para empleado</button></a></a></h3>
	@include('usuario.control.search')
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>COD</center></td>
					<td><center>Nombre</center></td>
					<td><center>Contraseña</center></td>
					<td><center>Cliente</center></td>
					<td><center>Empleado</center></td>
					<td><center>Rol</center></td>
				</thead>

				@foreach ($empleado as $e)
				<tr>
					<td>{{ $e->codigo }}</td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td>{{ $e->nombre }}</td>
					<td>{{ $e->contraseña }}</td>
					<td>{{ $e->persona }}</td>
					<td>
						<td><a href="{{URL::action('UsuarioController@edit',$e->codigo)}}"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-{{$e->codigo}}" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a></td>
					</td>
				</tr>
				@include('usuario.control.modal')
				@endforeach
			</table>
		</div>
	</div>
</div>

@endsection