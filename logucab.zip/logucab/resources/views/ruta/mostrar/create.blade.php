@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nueva ruta</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::open(array('url'=>'ruta/mostrar', 'method'=>'POST', 'autocomplete'=>'off'))!!}
		{{Form::token()}}

		<div class="form-group">
			<label for="origen">Origen</label>
					<select name="fk_sucursal_origen" class="form-control">
						@foreach ($sucursal as $suc)
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<label for="destino">Destino</label>
					<select name="fk_sucursal_destino" class="form-control">
						@foreach ($sucursal as $suc)
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endforeach
					</select>					
		</div>
		<div class="form-group">
			<label for="costo">Costo</label>
			<input type="text" name="costo" class="form-control" placeholder="Costo">	
		</div>
		<div class="form-group">
			<label for="duracion">Duración (mins)</label>
			<input type="text" name="duracion" class="form-control" placeholder="Duración">	
		</div>			


		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>
	  			</div>		
	</div>
@endsection