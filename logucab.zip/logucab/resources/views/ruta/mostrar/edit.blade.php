@extends('layouts.admin')
@section('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Ruta: {{ $ruta->id }}</h3>
			@if (count($errors)>0)
			<div class="aler alert-danger">
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{$error}}</li>
					@endforeach
				</ul>				
			</div>
		@endif



		{!!Form::model($ruta,['method'=>'PATCH', 'route'=>['mostrar.update', $ruta->id]])!!}
		{{Form::token()}}
		<div class="form-group">
			<label for="origen">Origen</label>
					<select name="fk_sucursal_origen" class="form-control">
						@foreach ($sucursal as $suc)
						@if ($suc->codigo==$ruta->fk_sucursal_origen)
						<option value="{{$suc->codigo}}" selected>{{$suc->nombre}}</option>@else
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endif
						@endforeach
					</select>	
		</div>	
		<div class="form-group">
			<label for="destino">Destino</label>
					<select name="fk_sucursal_destino" class="form-control">
						@foreach ($sucursal as $suc)
						@if ($suc->codigo==$ruta->fk_sucursal_destino)
						<option value="{{$suc->codigo}}" selected>{{$suc->nombre}}</option>@else
						<option value="{{$suc->codigo}}">{{$suc->nombre}}</option>
						@endif
						@endforeach
					</select>	
		</div>
		<div class="form-group">
			<label for="costo">Costo</label>
			<input type="text" name="costo" required value="{{$ruta->costo}}" class="form-control">
		</div>
		<div class="form-group">
			<label for="duracion">Duración</label>
			<input type="text" name="duracion" required value="{{$ruta->duracion}}" class="form-control">
		</div>

		<div class="form-group">
			<a href="{{URL::action('RutaController@index')}}"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			{!!Form::close()!!}

		</div>		
	</div>
@endsection