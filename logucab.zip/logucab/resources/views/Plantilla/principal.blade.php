@extends('layouts.admin')
@section('contenido')
<head>
	<link rel='stylesheet' href="{{asset('http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css')}}">
</head>	  

 <body class="hold-transition skin-purple  sidebar-mini ">
	    <div class="wrapper" style="background: white">

	      <header class="main-header">
	      	<style type="">
	      		.main-header {	
				  width: 100%; 
   				  left: 0; 
				  top: 0; 
	              position: fixed; }
	      	</style>

	        <!-- Logo -->
	        <a href="index2.html" class="logo" style='height: 69px'>
	          <!-- mini logo for sidebar mini 50x50 pixels -->
	          	<span class="logo-mini"><b>UCA</b>B</span>
	          <!-- logo for regular state and mobile devices -->
	           
	          

	          	<span class="logo-lg"> <div align="center"><IMG src="img/Logo.png" width="80px" height="70px"></div></span>
	    	</a>

	        <!-- Header Navbar: style can be found in header.less -->
	        <nav class="navbar navbar-static-top" role="navigation" style='height: 69px'>
	          <!-- Sidebar toggle button-->
	          <!--<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">-->
	            <span class="sr-only">Navegación</span>
	          </a>
	          <!-- Navbar Right Menu -->
	          <div class="navbar-custom-menu">
	            <ul class="nav navbar-nav">
	              <!-- Messages: style can be found in dropdown.less-->
	              
	              <!-- User Account: style can be found in dropdown.less -->
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/Plantilla/principal') }}">Inicio</a>
                    @else
	                  <li class="user-header">

						 <a href="{{ route('login') }}"><button class="btn btn-primary" type="submit" style="position: absolute; top: 25%; margin-left: -290px; height: 35px;" >Iniciar Sesion</button></a>
						<a href="{{ route('register') }}"><button class="btn btn-primary" type="submit" style="position: relative; top: 17px; margin-left: -140px; height: 35px;">Registrarse</button></a>
	                  </li>
                    @endauth
                </div>
            @endif	              


	            </ul>
	          </div>

	        </nav>
	      </header>
	  </div>
	<div id="carousel-example" class="carousel slide" data-ride="carousel" style='width: 1080px'>
	  	     <ol class="carousel-indicators">
	    		<li data-target="#carousel-example" data-slide-to="0" class="active"></li>
	    		<li data-target="#carousel-example" data-slide-to="1"></li>
	    		<li data-target="#carousel-example" data-slide-to="2"></li>
	 		 </ol>

	  <div class="carousel-inner">
	    <div class="item active">
	              <a href="#"><div class="uno"><img src="img/uno.jpg" style= 'width:1080px' 'height:800px'/></div></a>
	    </div>
	    <div class="item">
	        <a href="#"><img src="img/dos2.jpeg" style= 'width:1080px' 'height:400px'/></a>       
	    </div>
	    <div class="item">
	        <a href="#"><img src="img/tres3.jpg"style= 'width:1080px' 'height:400px' /></a>
	    </div>
	</div>

	    <style type="text/css">
	    .carousel {
	    position: absolute;
	    top:-5px; 
	    width: 1000px;
	    margin-left: -25px;
	    }
	    .uno{
	    	position: relative;
	    	margin-left: -10px;
	    }
	  </style>


	  <a class="left carousel-control" href="{{asset('#carousel-example')}}" data-slide="prev">
	    <span class="{{asset('glyphicon glyphicon-chevron-left')}}"></span>
	  </a>
	  <a class="right carousel-control" href="{{asset('#carousel-example')}}" data-slide="next">
	    <span class="{{asset('glyphicon glyphicon-chevron-right')}}"></span>
	  </a>
	</div>
	  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>

		    <div class="">
	       		<a href="#"><img src="img/contactenos.png"
	       			style= "position: absolute; width:250px; height:200px; left: 700px; top: 480px"/></a>
	   		 </div>

	  					<div class="text">
	 					  <p>LogUCAB es</p>
	 						 <p>
	   						   <span class="word wisteria">eficiencia.</span>
	    					   <span class="word belize">rapidez.</span>
	  						</p>
	      					<span>Escríbenos ante alguna duda o sugerencia.</span>
						</div>
			<style type="">
							.text {
 								 position: absolute;
  								 width: 450px;
  								 left: 50%;
							     margin-left: -335px;
 								 height: 40px;
 								 top: 23%;
 								 margin-top: -20px;
 								 font-family: 'Open Sans', sans-serif;
 								 font-weight: 600;
 								 font-size: 40px;
							}
						.text2 {
 							  position: absolute;
							  width: 700px;
							  left: 63%;
							  margin-left: -265px;
							  height: 40px;
							  top: 140%;
							  margin-top: -20px;
							  font-family: 'Open Sans', sans-serif;
							  font-weight: 600;
							  font-size: 40px;
						}

							p {
  								 display: inline-block;
 								 vertical-align: top;
 								 margin: 0;
							}

							.word {
  								 position: absolute;
 								 width: 220px;
 								 opacity: 0;
							}

							.letter {
 								 display: inline-block;
 								 position: relative;
 								 float: left;
 								 -webkit-transform: translateZ(25px);
         						 transform: translateZ(25px);
 								 -webkit-transform-origin: 50% 50% 25px;
         						 transform-origin: 50% 50% 25px;
							}

							.letter.out {
  								-webkit-transform: rotateX(90deg);
         						 transform: rotateX(90deg);
 								 transition: -webkit-transform 0.32s cubic-bezier(0.55, 0.055, 0.675, 0.19);
 								 transition: transform 0.32s cubic-bezier(0.55, 0.055, 0.675, 0.19);
 								 transition: transform 0.32s cubic-bezier(0.55, 0.055, 0.675, 0.19), -webkit-transform 0.32s cubic-bezier(0.55, 0.055, 0.675, 0.19);
							}

							.letter.behind {
 								 -webkit-transform: rotateX(-90deg);
         						  transform: rotateX(-90deg);
							}

							.letter.in {
  								 -webkit-transform: rotateX(0deg);
        						 transform: rotateX(0deg);
 								 transition: -webkit-transform 0.38s cubic-bezier(0.175, 0.885, 0.32, 1.275);
 								 transition: transform 0.38s cubic-bezier(0.175, 0.885, 0.32, 1.275);
 								 transition: transform 0.38s cubic-bezier(0.175, 0.885, 0.32, 1.275), -webkit-transform 0.38s cubic-bezier(0.175, 0.885, 0.32, 1.275);
							}

							.wisteria {
 								 color: #8e44ad;
							}

							.belize {
 								 color: #2980b9;
							}
							.pomegranate {
							  	 color: #c0392b;
							}

							.green {
							 	 color: #16a085;
							}

							.midnight {
							 	 color: #2c3e50;
							}
							.underline--magical {
								  background-image: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%);
								  background-repeat: no-repeat;
								  background-size: 100% 0.2em;
								  background-position: 0 88%;
								  transition: background-size 0.25s ease-in;
							}
							.underline--magical:hover {
							 	 background-size: 100% 88%;
							}

	   		 </style>		
			<div class="">
	       		<a href="#"><img src="img/agencias.jpg" class='imgRedonda' style= "position: absolute; width:250px; height:200px; left: 30px; top: 730px"/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad2{
	   		 		position: relative;
	   		 		margin-left: 290px;
	   		 		top: 530px;
	   		 	}
	   		 	.imgRedonda {
    				width:500px;
    				height:500px;
    				border-radius:150px;
				}
	   		 </style>
	  					<div class="text" style="position: absolute; top: 740px; left:700px">
	      						<span>Implementamos <span class="underline--magical">nuevas</span> oficinas al alcance de tu mano.</span>
						</div>
						<style type="">

							.underline--magical {
								  background-image: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%);
								  background-repeat: no-repeat;
								  background-size: 100% 0.2em;
								  background-position: 0 88%;
								  transition: background-size 0.25s ease-in;

							}
							.underline--magical:hover {
							 	 background-size: 100% 88%;
							}

						</style>

			<div class="">
	       		<a href="#"><img src="img/ingresa.jpg" class='imgRedonda1' style= "position: absolute; width:250px; height:200px; left: 30px; top: 1030px"/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad3{
	   		 		position: relative;
	   		 		margin-left: 300px;
	   		 		top: 650px;
	   		 	}
	   		 	.imgRedonda1 {
    				width:200px;
    				height:190px;
    				border-radius:100px;
				}
	   		 </style>
	      	  				<div class="text" style="position: absolute; top: 1270px; left:390px; font-size: 22px">
	      						<span>Regístrate gratis!</span> 
							</div>
			

			<div class="">
	       		<a href="#"><img src="img/envia.jpg" class='imgRedonda' style= "position: absolute; width:250px; height:200px; left: 400px; top: 1030px"/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad4{
	   		 		position: relative;
	   		 		margin-left: 620px;
	   		 		top: 450px;
	   		 	}
	   		 	.imgRedonda {
    				width:200px;
    				height:200px;
    				border-radius:150px;
				}
	   		 </style>
	      	  				<div class="text" style="position: absolute; top: 1270px; left:740px; font-size: 22px">
	      						<span>Registra tus paquetes</span> 
							</div>

			<div class="">
	       		<a href="#"><img src="img/pago.jpg" class='imgRedonda' style= "position: absolute; width:250px; height:200px; left: 740px; top: 1030px"/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad5{
	   		 		position: relative;
	   		 		margin-left: 950px;
	   		 		top: 250px;
	   		 	}
	   		 	.imgRedonda {
    				width:200px;
    				height:200px;
    				border-radius:150px;
				}
	   		 </style>
	      	  				<div class="text" style="position: absolute; top: 1270px; left:1050px; font-size: 22px">
	      						<span>Distintos métodos de pago</span> 
							</div>		

			<div class="">
	       		<a href="#"><img src="img/peso.png" style= "position: relative;  left: 500px; top: 700px"/></a>
	   		</div>
				
			<div class="">
	       		<a href="#"><img src="img/publi.png" style= "position: relative;  left: 100px; top: 800px"/></a>
	   		</div>

			<div class="">
	       		<a href="#"><img src="img/aereo.jpg" style= "position: relative;  left: 30px; top: -92px"/></a>
	   		</div>


<br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>


	    <!-- jQuery 2.1.4 -->
	    <script src="{{asset('js/jQuery-2.1.4.min.js')}}"></script>
	    <!-- Bootstrap 3.3.5 -->
	    <script src="{{asset('js/bootstrap.min.js')}}"></script>
	    <!-- AdminLTE App -->
	    <script src="{{asset('js/app.min.js')}}"></script>

	    <script  src="{{asset('fuente/js/index.js')}}"></script>
	   	<script  src="{{asset('fuente/js1/index.js')}}"></script>


@endsection
</body>


