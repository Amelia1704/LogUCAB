	<!DOCTYPE html>
	<html>
	  <head>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <title>LogUCAB</title>

	    <!-- Tell the browser to be responsive to screen width -->
	    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	    <!-- Bootstrap 3.3.5 -->
	    <link rel="stylesheet" href="css/bootstrap.min.css">
	    <!-- Font Awesome -->
	    <link rel="stylesheet" href="css/font-awesome.css">
	    

	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
		<link rel="stylesheet" href="fuente/css/style.css">
	   

	    <!-- Theme style -->
	    <link rel="stylesheet" href="css/AdminLTE.min.css">
	    <!-- AdminLTE Skins. Choose a skin from the css/skins
	         folder instead of downloading all of them to reduce the load. -->
	    <link rel="stylesheet" href="css/_all-skins.min.css">
	    <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
	    <link rel="shortcut icon" href="img/favicon2.ico">
	    <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css'>




	  </head>


	  <body class="hold-transition skin-purple  sidebar-mini ">
	    <div class="wrapper" style="background: white">

	      <header class="main-header">
	      	<style type="">
	      		.main-header {	
				  width: 100%; 
   				  left: 0; 
				  top: 0; 
	              position: fixed; }
	      	</style>

	        <!-- Logo -->
	        <a href="index2.html" class="logo" style='height: 69px'>
	          <!-- mini logo for sidebar mini 50x50 pixels -->
	          	<span class="logo-mini"><b>UCA</b>B</span>
	          <!-- logo for regular state and mobile devices -->
	           
	          

	          	<span class="logo-lg"> <div align="center"><IMG src="img/Logo.png" width="80px" height="70px"></div></span>
	    	</a>

	        <!-- Header Navbar: style can be found in header.less -->
	        <nav class="navbar navbar-static-top" role="navigation" style='height: 69px'>
	          <!-- Sidebar toggle button-->
	          <!--<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">-->
	            <span class="sr-only">Navegación</span>
	          </a>
	          <!-- Navbar Right Menu -->
	          <div class="navbar-custom-menu">
	            <ul class="nav navbar-nav">
	              <!-- Messages: style can be found in dropdown.less-->
	              
	              <!-- User Account: style can be found in dropdown.less -->
	              
	                  <li class="user-header">
						<button class="btn btn-primary" type="submit" style="position: absolute; top: 50%; margin-left: -290px;" >Iniciar Sesion</button>
						<button class="btn btn-primary" type="submit" style="position: relative; top: 17px; margin-left: -140px; height: 35px;">Registrarse</button>
	                  </li>

	            </ul>
	          </div>

	        </nav>
	      </header>
	      <!-- Left side column. contains the logo and sidebar -->
	      <aside class="main-sidebar "  >
	      	   <style type="">
	      		  .main-sidebar {	
   				  left: 0; 
				  top: 0; 
	              position: fixed; }
	      	   </style>

	        <!-- sidebar: style can be found in sidebar.less -->
	        <section class="sidebar">
	          <!-- Sidebar user panel -->
	                    
	          <!-- sidebar menu: : style can be found in sidebar.less -->
	          <ul class="sidebar-menu">

	            <li class="header"></li>
	            
	            <li class="treeview">
	              <a href="#">
	                <i class="fa fa-truck" aria-hidden="true"></i>
	                <span>Transportes</span>
	                <i class="fa fa-angle-left pull-right"></i>
	              </a>
	              <ul class="treeview-menu">
	                <li><a href="transportes/nacionales"><i class="fa fa-circle-o"></i> Nacionales</a></li>
	                <li><a href="transportes/internacionales"><i class="fa fa-circle-o"></i> Internacionales</a></li>
	              </ul>
	            </li>
	            
	            <li class="treeview">
	              <a href="#">
	                <i class="fa fa-hand-o-right" aria-hidden="true"></i>
	                <span>Sugerencia de envíos</span>
	                <small class="label pull-right bg-red">PDF</small>
	                 <i class="fa fa-angle-left pull-right"></i>
	              </a>
	             
	            </li>
	            <li>
	              <a href="#">
	                <i class="fa fa-map-o" aria-hidden="true"></i>
	                <span>Rastreo de paquete</span>
	              </a>
	            </li>
	                       
	            <li class="treeview">
	              <a href="#">
	                <i class="fa fa-users" aria-hidden="true"></i>
	                <span>Acceso</span>
	                <i class="fa fa-angle-left pull-right"></i>
	              </a>
	              <ul class="treeview-menu">
	                <li><a href="acceso/iniciar-sesion"><i class="fa fa-circle-o"></i> Iniciar sesión</a></li>
	                
	              </ul>
	            </li>
	             <li>
	              <a href="#">
	                <i class="fa fa-building" aria-hidden="true"></i> <span>Agencias</span>
	              </a>
	            </li>
	            <li>
	              <a href="#">
	                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i><span>Reclamos</span>
	              </a>
	            </li>
	            <li>
	            <li>
	              <a href="#">
	                <i class="fa fa-phone" aria-hidden="true"></i><span>Contactenos</span>
	              </a>
	            </li>
	            <li>
	              <a href="#">
	                <i class="fa fa-info-circle"></i> <span>Nosotros</span>
	                <small class="label pull-right bg-yellow">LogUCAB</small>
	              </a>
	            </li>
	                        
	          </ul>
	        </section>
	        <!-- /.sidebar -->
	      </aside>


	<div id="carousel-example" class="carousel slide" data-ride="carousel" style='width: 1080px'>
	  	     <ol class="carousel-indicators">
	    		<li data-target="#carousel-example" data-slide-to="0" class="active"></li>
	    		<li data-target="#carousel-example" data-slide-to="1"></li>
	    		<li data-target="#carousel-example" data-slide-to="2"></li>
	 		 </ol>

	  <div class="carousel-inner">
	    <div class="item active">
	              <a href="#"><div class="uno"><img src="img/uno.jpg" style= 'width:1080px' 'height:800px'/></div></a>
	    </div>
	    <div class="item">
	        <a href="#"><img src="img/dos2.jpeg" style= 'width:1080px' 'height:400px'/></a>       
	    </div>
	    <div class="item">
	        <a href="#"><img src="img/tres3.jpg"style= 'width:1080px' 'height:400px' /></a>
	    </div>
	</div>

	    <style type="text/css">
	    .carousel {
	    position: absolute;
	    top:50px; 
	    width: 1000px;
	    margin-left: 230px;
	    }
	    .uno{
	    	position: relative;
	    	margin-left: 0px;
	    }
	  </style>


	  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
	    <span class="glyphicon glyphicon-chevron-left"></span>
	  </a>
	  <a class="right carousel-control" href="#carousel-example" data-slide="next">
	    <span class="glyphicon glyphicon-chevron-right"></span>
	  </a>
	</div>
	  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>


		    <div class="publicidad1">
	       		   <a href="#"><img src="img/contactenos.png"style= 'width:300px' 'height:300px' /></a>
	   		 </div>

	   		 <style type="">
	   		 	.publicidad1{
	   		 		position: relative;
	   		 		margin-left: 880px;
	   		 		top: 530px;
	   		 	}
	   		 </style>

	  					<div class="text">
	 					  <p>LogUCAB es</p>
	 						 <p>
	   						   <span class="word wisteria">eficiencia.</span>
	    					   <span class="word belize">rapidez.</span>
	  						</p>
	      						<span>Escríbenos ante alguna duda o sugerencia.</span>
						</div>
			<div class="publicidad2">
	       		<a href="#"><img src="img/agencias.jpg" class='imgRedonda'/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad2{
	   		 		position: relative;
	   		 		margin-left: 290px;
	   		 		top: 530px;
	   		 	}
	   		 	.imgRedonda {
    				width:500px;
    				height:500px;
    				border-radius:150px;
				}
	   		 </style>	

	  					<div class="text2">
	      						<span>Implementamos <span class="underline--magical">nuevas</span> oficinas al alcance de tu mano.</span>
						</div>

				<div class="publicidad3">
	       		<a href="#"><img src="img/ingresa.jpg" class='imgRedonda1'/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad3{
	   		 		position: relative;
	   		 		margin-left: 300px;
	   		 		top: 650px;
	   		 	}
	   		 	.imgRedonda1 {
    				width:200px;
    				height:190px;
    				border-radius:100px;
				}
	   		 </style>
	      	  				<div class="text3">
	      						<span>Regístrate gratis!</span> 
							</div>
			
			<div class="publicidad4">
	       		<a href="#"><img src="img/envia.jpg" class='imgRedonda'/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad4{
	   		 		position: relative;
	   		 		margin-left: 620px;
	   		 		top: 450px;
	   		 	}
	   		 	.imgRedonda {
    				width:200px;
    				height:200px;
    				border-radius:150px;
				}
	   		 </style>
	      	  				<div class="text4">
	      						<span>Registra tus paquetes</span> 
							</div>
			
			<div class="publicidad5">
	       		<a href="#"><img src="img/pago.jpg" class='imgRedonda'/></a>
	   		</div>

	   		 <style type="">
	   		 	.publicidad5{
	   		 		position: relative;
	   		 		margin-left: 950px;
	   		 		top: 250px;
	   		 	}
	   		 	.imgRedonda {
    				width:200px;
    				height:200px;
    				border-radius:150px;
				}
	   		 </style>
	      	  				<div class="text5">
	      						<span>Distintos métodos de pago</span> 
							</div>

			<div class="publicidad6">
	       		<a href="#"><img src="img/peso.png"/></a>
	   		</div>
	   		 <style type="">
	   		 	.publicidad6{
	   		 		position: relative;
	   		 		margin-left: 800px;
	   		 		top: 420px;
	   		 	}
	   		 </style>

			<div class="publicidad7">
	       		<a href="#"><img src="img/publi.png"/></a>
	   		</div>
	   		 <style type="">
	   		 	.publicidad7{
	   		 		position: relative;
	   		 		margin-left: 400px;
	   		 		top: 450px;
	   		 	}

	   		 </style>

			<div class="publicidad8">
	       		<a href="#"><img src="img/aereo.jpg"/></a>
	   		</div>
	   		 <style type="">
	   		 	.publicidad8{
	   		 		position: relative;
	   		 		margin-left: 300px;
	   		 		top: -370px;
	   		 	}

	   		 </style>
	    <!-- jQuery 2.1.4 -->
	    <script src="js/jQuery-2.1.4.min.js"></script>
	    <!-- Bootstrap 3.3.5 -->
	    <script src="js/bootstrap.min.js"></script>
	    <!-- AdminLTE App -->
	    <script src="js/app.min.js"></script>

	    <script  src="fuente/js/index.js"></script>
	   	<script  src="fuente/js1/index.js"></script>

	       <footer class="main-footer">
	       	<center>
	          <strong>© 2018 LogUCAB.com 
	        	<a href="www.incanatoit.com">- Todos los derechos reservados.</a>
	        	 <a href="www.incanatoit.com">- Términos y condiciones 
	        	 	<a href="www.incanatoit.com">-Política de privacidad </strong> 
	        </center>
	      </footer>


	    
	  </body>
	</html>
