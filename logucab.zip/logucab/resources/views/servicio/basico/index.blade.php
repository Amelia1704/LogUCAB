@extends('layouts.admin')
@section('contenido')

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Servicios por sucursal <a href="ver/create"></a></h3>
	@include('transporte.taller.search')
</div>
</div>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

			<h4>Listado</h2>
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>Servicio</td>
					<td>Sucursal</td>
				</thead>

				@foreach ($listado as $l)
				<tr>
					<td>{{ $l->servicio }}</td>
					<td>{{ $l->sucursal }}</td>
				</tr>
				@endforeach
			</table>
			{{$listado->render()}}
	</div>
</div>

@endsection