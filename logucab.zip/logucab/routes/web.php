<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('../Plantilla/principal');
});
Route::resource('sucursal/ver','SucursalController');
Route::resource('sucursal/aeropuerto','AeropuertoController');
Route::resource('sucursal/puerto','PuertoController');
Route::resource('servicio/basico','ServicioController');
Route::resource('cliente/lista','ClienteController');
Route::resource('transporte/aereo','AereoController');
Route::resource('transporte/terrestre','TerrestreController');
Route::resource('transporte/maritimo','MaritimoController');
Route::resource('transporte/taller','TallerController');
Route::resource('empleado/activo','EmpleadoController');
Route::resource('empleado/inactivo','EmpleadoIController');
Route::resource('empleado/horario','HorarioController');
Route::resource('empleado/asistencia','AsistenciaController');
Route::resource('ruta/mostrar','RutaController');
Route::resource('rol','RolController');
Route::resource('usuario/control','UsuarioController');
Route::post('usuario/control/storedos', 'UsuarioController@storedos');
Route::resource('envio/paquete','PaqueteController');
Route::resource('envio/enviar','EnvioController');
Route::get('envio/enviar/create/{id}','EnvioController@create');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
