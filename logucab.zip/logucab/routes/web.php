<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('../Plantilla/principal');
});
Route::resource('sucursal/ver','SucursalController');
Route::resource('cliente/lista','ClienteController');
Route::resource('transporte/aereo','AereoController');
Route::resource('transporte/terrestre','TerrestreController');
Route::resource('transporte/maritimo','MaritimoController');
Route::resource('empleado/activo','EmpleadoController');
Route::resource('ruta/mostrar','RutaController');