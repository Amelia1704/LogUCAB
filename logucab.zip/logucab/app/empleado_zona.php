<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class empleado_zona extends Model
{
    protected $table = 'empleado_zona';
    protected $primaryKey = 'clave';

    public $timestamps = false;

    protected $fillable = [
    	'descripcion',
    	'fk_empleado',
    	'fk_zona',
    ];
    
    protected $guarded = [

    ];
}
