<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\aereo;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\AereoFormRequest;
use DB;


class AereoController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$aereos=DB::table('transporte as t')
    		->join('sucursal as s', 't.fk_sucursal', '=', 's.codigo')
    		->select('t.codigo', 't.clasificacion', 't.capacidad_carga', 't.serial_motor','t.matricula', 't.marca', 't.modelo', 't.fecha_vehiculo', 't.longitud', 't.envergadura', 't.area', 't.altura', 't.ancho_cabina', 't.diametro_fuselaje', 't.peso_vacio', 't.peso_maximo', 't.carrera_despeje', 't.velocidad_maxima', 't.capacidad_combustible', 't.cantidad_motor', 't.tipo', 's.nombre as sucursal')
            ->where('t.clasificacion', '=', 'Aéreo')
            ->where('t.codigo','LIKE','%'.$query.'%')
	   		->orderBy('t.serial_motor', 'asc')
    		->paginate(7);
            
            $usados=DB::table('envio_transporte as et')
            ->select(\DB::raw("COUNT(et.fk_transporte) AS numero"), 'et.fk_transporte AS codigo_del_transporte')
            ->orderBy(\DB::raw("COUNT(et.fk_transporte)"), 'desc')
            ->groupBy('et.fk_transporte')
            ->take(5)
            ->get();

    		return view('transporte.aereo.index', ["aereos"=>$aereos, "usados"=>$usados, "searchText"=>$query]);
    	}
    }
 
    public function create(){
        $sucursal=DB::table('sucursal')->get();
    	return view("transporte.aereo.create",["sucursal"=>$sucursal]);
    }

    public function store(AereoFormRequest $request){
    	$transporte=new Aereo;	
    	$transporte->clasificacion='Aéreo';
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->longitud=$request->get('longitud');
    	$transporte->envergadura=$request->get('envergadura');
    	$transporte->area=$request->get('area');
    	$transporte->altura=$request->get('altura');
    	$transporte->ancho_cabina=$request->get('ancho_cabina');
    	$transporte->diametro_fuselaje=$request->get('diametro_fuselaje');
    	$transporte->peso_vacio=$request->get('peso_vacio');
    	$transporte->peso_maximo=$request->get('peso_maximo');
    	$transporte->carrera_despeje=$request->get('carrera_despeje');
    	$transporte->velocidad_maxima=$request->get('velocidad_maxima');
    	$transporte->capacidad_combustible=$request->get('capacidad_combustible');
    	$transporte->cantidad_motor=$request->get('cantidad_motor');
    	$transporte->tipo='Avion';
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->save();
    	return Redirect::to('transporte/aereo');	
    }

    public function show($id){
		return view("transporte.aereo.show",["transporte"=>Aereo::findOrFail($id)]);
    }

    public function edit($id){
        $transporte=Aereo::findOrFail($id);
        $sucursal=DB::table('sucursal')->get();
        return view("transporte.aereo.edit",["transporte"=>$transporte, "sucursal"=>$sucursal]);
    }

    public function update(AereoFormRequest $request, $id){
    	$transporte=Aereo::findOrFail($id);
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->longitud=$request->get('longitud');
    	$transporte->envergadura=$request->get('envergadura');
    	$transporte->area=$request->get('area');
    	$transporte->altura=$request->get('altura');
    	$transporte->ancho_cabina=$request->get('ancho_cabina');
    	$transporte->diametro_fuselaje=$request->get('diametro_fuselaje');
    	$transporte->peso_vacio=$request->get('peso_vacio');
    	$transporte->peso_maximo=$request->get('peso_maximo');
    	$transporte->carrera_despeje=$request->get('carrera_despeje');
    	$transporte->velocidad_maxima=$request->get('velocidad_maxima');
    	$transporte->capacidad_combustible=$request->get('capacidad_combustible');
    	$transporte->cantidad_motor=$request->get('cantidad_motor');
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->update();
    	return Redirect::to('transporte/aereo');	
    }  
    public function destroy($id){

    	$aereo = Aereo::findOrFail($id);
		$aereo->delete();
    	return Redirect::to('transporte/aereo');	
    }  
}
