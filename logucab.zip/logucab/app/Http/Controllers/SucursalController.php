<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\sucursal;
use logUcab\telefono;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\SucursalFormRequest;
use DB;

class SucursalController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$sucursales=DB::table('sucursal as s')
    		->join('lugar as l', 's.fk_lugar', '=', 'l.codigo')
    		->join('personacontacto as p', 's.fk_personacontacto', '=', 'p.id')
            ->join('telefono as t', 's.codigo', '=', 't.fk_sucursal')
    		->select('s.codigo', 's.nombre', 's.capacidad', 't.numero as telefono', 's.email','s.capacidad_almacenamiento', 
            'l.nombre as lugar', 'p.nombre as contacto', 'p.cedula as contacto2')
            ->where('s.codigo','LIKE','%'.$query.'%')
	   		->orderBy('s.codigo', 'asc')
    		->paginate(7);
    		return view('sucursal.ver.index', ["sucursales"=>$sucursales, "searchText"=>$query]);
    	}
    }

    public function create(){
        $lugar=DB::table('lugar')->where('tipo', '=', 'Municipio')->get();
        $personacontacto=DB::table('personacontacto')->where('nombre', '!=', 'inactivo')->get();
    	return view("sucursal.ver.create",["lugar"=>$lugar],["personacontacto"=>$personacontacto]);
    }

    public function store(SucursalFormRequest $request){
    	$sucursal=new Sucursal;	
    	$sucursal->nombre=$request->get('nombre');
    	$sucursal->capacidad=$request->get('capacidad');
    	$sucursal->email=$request->get('email');
    	$sucursal->capacidad_almacenamiento=$request->get('capacidad_almacenamiento');
    	$sucursal->fk_lugar=$request->get('fk_lugar');
    	$sucursal->fk_personacontacto=$request->get('fk_personacontacto');
    	$sucursal->save();

        $telefono = new Telefono;
        $telefono->numero = $request->get('numero');
        $telefono->tipo = 'Móvil';
        $telefono->fk_sucursal = $sucursal->codigo;
        $telefono->save(); 
    	return Redirect::to('sucursal/ver');	
    }

    public function show($id){
		return view("sucursal.ver.show",["sucursal"=>Sucursal::findOrFail($id)]);
    }

    public function edit($id){
        $sucursal=Sucursal::findOrFail($id);
        $lugar=DB::table('lugar')->where('tipo', '=', 'Parroquia')->get();
        $personacontacto=DB::table('personacontacto')->where('nombre', '!=', 'inactivo')->get();
        $telefono=DB::table('telefono as t')->where('t.fk_sucursal', '=', $id)->get();
        return view("sucursal.ver.edit",["sucursal"=>$sucursal, "lugar"=>$lugar, 
        "personacontacto"=>$personacontacto, "telefono"=>$telefono]);
    }

    public function update(SucursalFormRequest $request, $id){
    	$sucursal=Sucursal::findOrFail($id);
    	$sucursal->nombre=$request->get('nombre');
    	$sucursal->capacidad=$request->get('capacidad');
    	$sucursal->email=$request->get('email');
    	$sucursal->capacidad_almacenamiento=$request->get('capacidad_almacenamiento');
    	$sucursal->fk_lugar=$request->get('fk_lugar');
    	$sucursal->fk_personacontacto=$request->get('fk_personacontacto');
    	$sucursal->update();

        $telefono=DB::table('telefono as t')->where('t.fk_sucursal', '=', $id)->delete();
        $telefono = new Telefono;
        $telefono->numero = $request->get('telefono');
        $telefono->tipo = 'Móvil';
        $telefono->fk_sucursal = $sucursal->codigo;
        $telefono->save();

    	return Redirect::to('sucursal/ver');	
    }    

    public function destroy($id){
        $sucursal = Sucursal::findOrFail($id);
        $telefono=DB::table('telefono')->where('fk_sucursal', '=', $id)->delete();
        $transporte=DB::table('transporte')->where('fk_sucursal', '=', $id)->get();

        foreach ($transporte as $t) {
            $ruta_transporte=DB::table('ruta_transporte')->where('fk_transporte', '=', $t->codigo)->delete();
        }

        $transporte=DB::table('transporte')->where('fk_sucursal', '=', $id)->delete();
        $ruta_origen=DB::table('ruta')->where('fk_sucursal_origen', '=', $id)->delete();
        $ruta_destino=DB::table('ruta')->where('fk_sucursal_destino', '=', $id)->delete();
        $sucursal->delete();
        return Redirect::to('sucursal/ver'); 
    }  
}
