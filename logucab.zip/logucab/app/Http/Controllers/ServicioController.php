<?php

namespace logUcab\Http\Controllers;
use Illuminate\Http\Request;
use logUcab\Http\Requests;
use logUcab\servicio;
use logUcab\sucursal;
use Illuminate\Support\Facades\Redirect;
use DB;

class ServicioController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));

            
            $listado=DB::table('servicio_sucursal as ss')
            ->join('servicio as ser' ,'ser.codigo', '=', 'ss.fk_servicio')
            ->join('sucursal as s' ,'s.codigo', '=', 'ss.fk_sucursal')
            ->select('ser.tipo as servicio', 's.nombre as sucursal')
			->paginate(7);

    		return view('servicio.basico.index', ["listado"=>$listado, "searchText"=>$query]);
    	}
    }
}