<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\Usuario;
use logUcab\Cliente;
use logUcab\Empleado;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\UsuarioFormRequest;
use DB;


class UsuarioController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$cliente=DB::table('usuario as u')
    		->join('cliente as c', 'u.fk_cliente', '=', 'c.id')
    		->select('u.codigo', 'u.nombre', 'u.contraseña', 'c.nombre as persona');
    		$empleado=DB::table('usuario as u')
    		->join('empleado as e', 'u.fk_empleado', '=', 'e.id')
    		->select('u.codigo', 'u.nombre', 'u.contraseña', 'e.nombre as persona')
    		->union($cliente)
    		->get();
    		return view('usuario.control.index', ["empleado"=>$empleado, "searchText"=>$query]);
    	}
    }

    public function create(){
        $cliente=DB::table('cliente')->get();
        $rol=DB::table('rol')->get();
    	return view("usuario.control.create",["cliente"=>$cliente, "rol"=>$rol]);
    }


    public function store(UsuarioFormRequest $request){
    	$usuario=new Usuario;	
    	$usuario->nombre=$request->get('nombre');
    	$usuario->contraseña=$request->get('contraseña');
    	$usuario->fk_cliente=$request->get('fk_cliente');
    	$usuario->fk_rol=$request->get('fk_rol');
    	$usuario->save();
    	return Redirect::to('usuario/control');	
    }

    public function storedos(UsuarioFormRequest $request){
    	$usuario=new Usuario;	
    	$usuario->nombre=$request->get('nombre');
    	$usuario->contraseña=$request->get('contraseña');
    	$usuario->fk_empleado=$request->get('fk_empleado');
    	$usuario->fk_rol=$request->get('fk_rol');
    	$usuario->save();
    	return Redirect::to('usuario/control');	
    }

    public function show($id){
        $empleado=DB::table('empleado')->get();
        $rol=DB::table('rol')->get();
    	return view("usuario.control.show",["empleado"=>$empleado, "rol"=>$rol]);
    }

    public function edit($id){
        $usuario=Usuario::findOrFail($id);
        $cliente=DB::table('cliente')->get();
        $empleado=DB::table('empleado')->get();
        $rol=DB::table('rol')->get();
        return view("usuario.control.edit",["usuario"=>$usuario, "cliente"=>$cliente, "empleado"=>$empleado, "rol"=>$rol ]);
    }

    public function update(UsuarioFormRequest $request, $id){
    	$usuario=new Usuario;	
    	$usuario->nombre=$request->get('nombre');
    	$usuario->contraseña=$request->get('contraseña');
    	$usuario->fk_cliente=$request->get('fk_cliente');
    	$usuario->fk_empleado=$request->get('fk_empleado');
    	$usuario->fk_rol=$request->get('fk_rol');
    	$usuario->update();
    	return Redirect::to('usuario/control');	
    }    

    public function destroy($id){
        $usuario = Usuario::findOrFail($id);
        Cliente::destroy($id);
        $usuario->delete();
        return Redirect::to('usuario/control'); 
    }

}
