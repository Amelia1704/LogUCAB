<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\cliente;
use logUcab\telefono;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\ClienteFormRequest;
use DB;

class ClienteController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$clientes=DB::table('cliente as c')
    		->join('lugar as l', 'c.fk_lugar', '=', 'l.codigo')
            ->join('sucursal as s', 'c.fk_sucursal', '=', 's.codigo')
            ->join('telefono as t', 'c.id', '=', 't.fk_cliente')
    		->select('c.id', 'c.cedula', 'c.nombre', 'c.apellido','c.fecha_nac',
    		'c.estado_civil','c.empresa','c.l_vip', 'l.nombre as lugar', 't.numero as telefono', 's.nombre as sucursal')
            ->where('c.nombre','LIKE','%'.$query.'%')         
	   		->orderBy('c.id', 'desc')
    		->paginate(7);
    		return view('cliente.lista.index', ["clientes"=>$clientes, "searchText"=>$query]);
    	}
    }

    public function create(){
        $lugar=DB::table('lugar')->where('tipo', '=', 'Parroquia')->get();
        $sucursal=DB::table('sucursal')->get();
    	return view("cliente.lista.create",["lugar"=>$lugar , "sucursal"=> $sucursal]);
    }

    public function store(ClienteFormRequest $request){
    	$cliente=new Cliente;
    	$cliente->cedula=$request->get('cedula');    	
    	$cliente->nombre=$request->get('nombre');
    	$cliente->apellido=$request->get('apellido');
    	$cliente->fecha_nac=$request->get('fecha_nac');
    	$cliente->estado_civil=$request->get('estado_civil');
    	$cliente->empresa=$request->get('empresa');
    	$cliente->l_vip='No';
    	$cliente->fk_lugar=$request->get('fk_lugar');
        $cliente->fk_sucursal=$request->get('fk_sucursal');
    	$cliente->save();

        $telefono = new Telefono;
        $telefono->numero = $request->get('numero');
        $telefono->tipo = 'Móvil';
        $telefono->fk_cliente = $cliente->id;
        $telefono->save();

    	return Redirect::to('cliente/lista');	
    }

    public function show($id){
		return view("cliente.lista.show",["cliente"=>Cliente::findOrFail($id)]);
    }

    public function edit($id){
        $cliente=Cliente::findOrFail($id);
        $lugar=DB::table('lugar')->where('tipo', '=', 'Parroquia')->get();
        $sucursal=DB::table('sucursal')->get();
        $telefono=DB::table('telefono as t')->where('t.fk_cliente', '=', $id)->get();

        return view("cliente.lista.edit",["cliente"=>$cliente, "lugar"=>$lugar, 
        "sucursal"=>$sucursal, "telefono"=>$telefono]);
    }

    public function update(ClienteFormRequest $request, $id){
    	$cliente=Cliente::findOrFail($id);
    	$cliente->cedula=$request->get('cedula');    	
    	$cliente->nombre=$request->get('nombre');
    	$cliente->apellido=$request->get('apellido');
    	$cliente->fecha_nac=$request->get('fecha_nac');
    	$cliente->estado_civil=$request->get('estado_civil');
    	$cliente->empresa=$request->get('empresa');
    	$cliente->l_vip='No';
    	$cliente->fk_lugar=$request->get('fk_lugar');
        $cliente->fk_sucursal=$request->get('fk_sucursal');
    	$cliente->update();

        $telefono=DB::table('telefono as t')->where('t.fk_cliente', '=', $id)->delete();
        $telefono = new Telefono;
        $telefono->numero = $request->get('telefono');
        $telefono->tipo = 'Móvil';
        $telefono->fk_cliente = $cliente->id;
        $telefono->save();

    	return Redirect::to('cliente/lista');	
    }    

    public function destroy($id){
        $cliente = Cliente::findOrFail($id);
        $telefono=DB::table('telefono')->where('fk_cliente', '=', $id)->delete();
        $cliente->delete();

        return Redirect::to('cliente/lista'); 
    }
}
