<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use DB;

class AeropuertoController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
        if ($request){
            $query=trim($request->get('searchText'));
            $aeropuertos=DB::table('aeropuerto as a')
            ->join('sucursal as s', 'a.fk_sucursal', '=', 's.codigo')
            ->select('a.codigo', 'a.nombre', 'a.cantidad_terminales', 'a.cantidad_pistas', 'a.capacidad', 's.nombre as sucursal')
            ->where('a.codigo','LIKE','%'.$query.'%')      
            ->orderBy('a.codigo', 'asc')
            ->paginate(7);
            return view('sucursal.aeropuerto.index', ["aeropuertos"=>$aeropuertos, "searchText"=>$query]);
        }
    }
}
