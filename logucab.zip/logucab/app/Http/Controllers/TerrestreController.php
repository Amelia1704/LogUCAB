<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\terrestre;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\TerrestreFormRequest;
use DB;

class TerrestreController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$terrestres=DB::table('transporte as t')
    		->join('sucursal as s', 't.fk_sucursal', '=', 's.codigo')
    		->select('t.codigo', 't.clasificacion', 't.capacidad_carga', 't.serial_motor','t.matricula', 't.marca', 't.modelo', 't.fecha_vehiculo', 't.serial_carroceria', 't.tipo', 's.nombre as sucursal')
            ->where('t.clasificacion', '=', 'Terrestre')
            ->where('t.codigo','LIKE','%'.$query.'%')
	   		->orderBy('t.serial_motor', 'asc')
    		->paginate(7);

            $usados=DB::table('envio_transporte as et')
            ->select(\DB::raw("COUNT(et.fk_transporte) AS numero"), 'et.fk_transporte AS codigo_del_transporte')
            ->orderBy(\DB::raw("COUNT(et.fk_transporte)"), 'desc')
            ->groupBy('et.fk_transporte')
            ->take(5)
            ->get();
    		return view('transporte.terrestre.index', ["terrestres"=>$terrestres, "usados"=>$usados, "searchText"=>$query]);
    	}
    }

    public function create(){
        $sucursal=DB::table('sucursal')->get();
    	return view("transporte.terrestre.create",["sucursal"=>$sucursal]);
    }

    public function store(TerrestreFormRequest $request){
    	$transporte=new Terrestre;	
    	$transporte->clasificacion='Terrestre';
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->serial_carroceria=$request->get('serial_carroceria');
    	$transporte->tipo=$request->get('tipo');
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->save();
    	return Redirect::to('transporte/terrestre');	
    }

    public function show($id){
		return view("transporte.terrestre.show",["transporte"=>Terrestre::findOrFail($id)]);
    }

    public function edit($id){
        $transporte=Terrestre::findOrFail($id);
        $sucursal=DB::table('sucursal')->get();
        return view("transporte.terrestre.edit",["transporte"=>$transporte, "sucursal"=>$sucursal]);
    }

    public function update(TerrestreFormRequest $request, $id){
    	$transporte=Terrestre::findOrFail($id);
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->serial_carroceria=$request->get('serial_carroceria');
    	$transporte->tipo=$request->get('tipo');
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->update();
    	return Redirect::to('transporte/terrestre');	
    }  
    public function destroy($id){

    	$terrestre = Terrestre::findOrFail($id);
		$terrestre->delete();
    	return Redirect::to('transporte/terrestre');	
    } 
}
