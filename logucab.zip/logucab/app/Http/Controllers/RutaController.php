<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\ruta;
use logUcab\ruta_transporte;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\RutaFormRequest;
use DB;

class RutaController extends Controller
{
	public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$rutas=DB::table('ruta as r')
    		->join('sucursal as s', 'r.fk_sucursal_origen', '=', 's.codigo')
    		->join('sucursal as s1', 'r.fk_sucursal_destino', '=', 's1.codigo')
            ->join('ruta_transporte as rt', 'r.id', '=', 'rt.fk_ruta')
            ->join('transporte as t', 'rt.fk_transporte', '=', 't.codigo')
    		->select('r.id', 's.nombre as origen', 's1.nombre as destino', 't.clasificacion', 
                    'r.costo', 'r.duracion')
            ->where('r.id','LIKE','%'.$query.'%')         
	   		->orderBy('r.id', 'asc')
    		->paginate(7);
    		return view('ruta.mostrar.index', ["rutas"=>$rutas, "searchText"=>$query]);
    	}
    }

    public function create(){
    	$sucursal=DB::table('sucursal')->get();
    	return view("ruta.mostrar.create",["sucursal"=>$sucursal]);
    }

    public function store(RutaFormRequest $request){
    	$ruta=new Ruta;
    	$ruta->costo=$request->get('costo');
    	$ruta->duracion=$request->get('duracion');
    	$ruta->fk_sucursal_origen=$request->get('fk_sucursal_origen');
    	$ruta->fk_sucursal_destino=$request->get('fk_sucursal_destino');
    	$ruta->save();

        $transporte=DB::table('transporte')->where('fk_sucursal', '=', $ruta->fk_sucursal_origen)
        ->where('clasificacion', '=', $request->get('transporte'))->get();

        foreach ($transporte as $t) {
            $rutra = new Ruta_transporte;
            $rutra->fk_ruta = $ruta->id;
            $rutra->fk_transporte = $t->codigo;
            $rutra->save();
        }
        
    	return Redirect::to('ruta/mostrar');	
    }

    public function show($id){
		return view("ruta.mostrar.show",["ruta"=>Ruta::findOrFail($id)]);
    }

    public function edit($id){
        $ruta=Ruta::findOrFail($id);
        $sucursal=DB::table('sucursal')->get();
        $transporte=DB::table('transporte as t')->join('ruta_transporte as rt', 'rt.fk_transporte', '=', 't.codigo')
        ->join('ruta as r', 'r.id', '=', 'rt.fk_ruta')->select('t.*', 'rt.fk_transporte as id')
        ->where('r.id', '=', $ruta->id)->get();
        return view("ruta.mostrar.edit",["ruta"=>$ruta, "sucursal"=>$sucursal, "transporte"=>$transporte]);
    }

    public function update(RutaFormRequest $request, $id){
    	$ruta=Ruta::findOrFail($id);
		$ruta->costo=$request->get('costo');    	
    	$ruta->duracion=$request->get('duracion');
    	$ruta->fk_sucursal_origen=$request->get('fk_sucursal_origen');
    	$ruta->fk_sucursal_destino=$request->get('fk_sucursal_destino');
    	$ruta->update();
    	return Redirect::to('ruta/mostrar');	
    }    

    public function destroy($id){

    	$ruta = Ruta::findOrFail($id);
        $ruta_transporte = DB::table('ruta_transporte')->where('fk_ruta', '=', $ruta->id)->delete();
		$ruta->delete();
    	return Redirect::to('ruta/mostrar');	
    }
}
