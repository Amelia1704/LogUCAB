<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\ruta;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\RutaFormRequest;
use DB;

class RutaController extends Controller
{
	public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$rutas=DB::table('ruta as r')
    		->join('sucursal as s', 'r.fk_sucursal_origen', '=', 's.codigo')
    		->join('sucursal as s1', 'r.fk_sucursal_destino', '=', 's1.codigo')
    		->select('r.id', 's.nombre as origen', 's1.nombre as destino', 'r.costo', 'r.duracion')
            ->where('r.id','LIKE','%'.$query.'%')         
	   		->orderBy('r.id', 'asc')
    		->paginate(7);
    		return view('ruta.mostrar.index', ["rutas"=>$rutas, "searchText"=>$query]);
    	}
    }

    public function create(){
    	$sucursal=DB::table('sucursal')->get();
    	return view("ruta.mostrar.create",["sucursal"=>$sucursal]);
    }

    public function store(RutaFormRequest $request){
    	$ruta=new Ruta;
    	$ruta->costo=$request->get('costo');
    	$ruta->duracion=$request->get('duracion');
    	$ruta->fk_sucursal_origen=$request->get('fk_sucursal_origen');
    	$ruta->fk_sucursal_destino=$request->get('fk_sucursal_destino');
    	$ruta->save();
    	return Redirect::to('ruta/mostrar');	
    }

    public function show($id){
		return view("ruta.mostrar.show",["ruta"=>Ruta::findOrFail($id)]);
    }

    public function edit($id){
        $ruta=Ruta::findOrFail($id);
        $sucursal=DB::table('sucursal')->get();
        return view("ruta.mostrar.edit",["ruta"=>$ruta, "sucursal"=>$sucursal]);
    }

    public function update(RutaFormRequest $request, $id){
    	$ruta=Ruta::findOrFail($id);
		$ruta->costo=$request->get('costo');    	
    	$ruta->duracion=$request->get('duracion');
    	$ruta->fk_sucursal_origen=$request->get('fk_sucursal_origen');
    	$ruta->fk_sucursal_destino=$request->get('fk_sucursal_destino');
    	$ruta->update();
    	return Redirect::to('ruta/mostrar');	
    }    

    public function destroy($id){

    	$ruta = Ruta::findOrFail($id);
		$ruta->delete();
    	return Redirect::to('ruta/mostrar');	
    }
}
