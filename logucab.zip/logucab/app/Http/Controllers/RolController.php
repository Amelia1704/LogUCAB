<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\Rol;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\RolFormRequest;
use DB;

class RolController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$roles=DB::table('rol')
    		->select('codigo', 'tipo')
            ->where('tipo','LIKE','%'.$query.'%')
	   		->orderBy('codigo', 'desc')
    		->paginate(7);
    		return view('rol.index', ["roles"=>$roles, "searchText"=>$query]);
    	}
    }

    public function create(){
    	return view("rol.create");
    }

    public function store(RolFormRequest $request){
    	$rol=new Rol;	
    	$rol->tipo=$request->get('tipo');
    	$rol->save();
    	return Redirect::to('rol');	
    }

    public function show($id){
		return view("rol.show",["rol"=>rol::findOrFail($id)]);
    }

    public function edit($id){
        $rol=Rol::findOrFail($id);
        return view("rol.edit",["rol"=>$rol]);
    }

    public function update(RolFormRequest $request, $id){
    	$rol=Rol::findOrFail($id);
    	$rol->tipo=$request->get('tipo');
    	$rol->update();
    	return Redirect::to('rol');	
    }    

    public function destroy($id){
        $rol = Rol::findOrFail($id);
        $rol->delete();
        return Redirect::to('rol'); 
    }
}
