<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\envio;
use logUcab\paquete;
use logUcab\telefono;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\EnvioFormRequest;
use DB;

class EnvioController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$envios=DB::table('envio as e');
    		return view('envio.envio.index', ["envios"=>$envios]);
    	}
    }

    public function create($codigo){
        $paquete=Paquete::findOrFail($codigo);
        $cliente=DB::table('cliente')->get();
        $sucursal=DB::table('sucursal')->get();
        $ruta=DB::table('ruta as r')
        ->join('sucursal as s', 'r.fk_sucursal_origen', '=', 's.codigo')
        ->join('sucursal as x', 'r.fk_sucursal_destino', '=', 'x.codigo')
        ->select('r.id', 's.nombre as origen', 'x.nombre as destino')->get();
    	return view("envio.enviar.create", ["cliente"=>$cliente, "paquete"=>$paquete, 
            "sucursal"=>$sucursal, "ruta"=>$ruta]);
    }

    public function store(EnvioFormRequest $request){
    	$envio=new Envio;
    	$envio->costo='3';    	
    	$envio->nombre_recibe=$request->get('nombre_recibe');
    	$envio->apellido_recibe=$request->get('apellido_recibe');
        $envio->email_recibe=$request->get('email_recibe');
        $envio->fk_cliente_envia=$request->get('fk_cliente_envia');
        $envio->fk_tipoenvio=$request->get('fk_tipoenvio');
        $envio->fk_paquete=$request->get('fk_paquete');

        $telefono = new Telefono;
        $telefono->numero = $request->get('telefono');
        $telefono->tipo = 'Móvil';
        $telefono->save();

        $envio->fk_telefono=$telefono->codigo;
        $envio->save();

    	return Redirect::to('envio/paquete');	
    }

    public function show($id){
		return view("envio.envio.show",["envios"=>Envio::findOrFail($id)]);
    }
}
