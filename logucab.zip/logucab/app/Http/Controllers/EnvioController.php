<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\envio;
use logUcab\paquete;
use logUcab\telefono;
use logUcab\cliente;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\EnvioFormRequest;
use DB;

class EnvioController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
        if ($request){
            $query=trim($request->get('searchText'));
            $envios=DB::table('envio as e')
            ->join('telefono as t', 'e.fk_telefono', '=', 't.codigo')
            ->join('cliente as c', 'e.fk_cliente_envia', '=', 'c.id')
            ->join('tipoenvio as te', 'e.fk_tipoenvio', '=', 'te.codigo')
            ->select('e.numero', 'e.costo', 'c.nombre as cliente_envia', 'e.nombre_recibe', 
            'e.apellido_recibe', 'e.email_recibe','t.numero as telefono', 'e.fk_paquete',
            'te.nombre as tipoenvio','e.fk_ruta')
            ->where('e.numero','LIKE','%'.$query.'%')       
            ->orderBy('e.numero', 'asc')
            ->paginate(7);

            return view('envio.enviar.index', ["envios"=>$envios, "searchText"=>$query]);
        }
    }

    public function create($codigo){
        $paquete=Paquete::findOrFail($codigo);
        $cliente=DB::table('cliente')->get();
        $sucursal=DB::table('sucursal')->get();
        $ruta=DB::table('ruta as r')
        ->join('sucursal as s', 'r.fk_sucursal_origen', '=', 's.codigo')
        ->join('sucursal as x', 'r.fk_sucursal_destino', '=', 'x.codigo')
        ->select('r.id', 's.nombre as origen', 'x.nombre as destino')->get();
    	return view("envio.enviar.create", ["cliente"=>$cliente, "paquete"=>$paquete, 
            "sucursal"=>$sucursal, "ruta"=>$ruta]);
    }

    public function store(EnvioFormRequest $request){
    	$envio=new Envio;
    	$envio->costo='3';    	
    	$envio->nombre_recibe=$request->get('nombre_recibe');
    	$envio->apellido_recibe=$request->get('apellido_recibe');
        $envio->email_recibe=$request->get('email_recibe');
        $envio->fk_cliente_envia=$request->get('fk_cliente_envia');
        $envio->fk_tipoenvio=$request->get('fk_tipoenvio');
        $envio->fk_paquete=$request->get('fk_paquete');
        $envio->fk_ruta=$request->get('fk_ruta');

        $telefono = new Telefono;
        $telefono->numero = $request->get('telefono');
        $telefono->tipo = 'Móvil';
        $telefono->save();

        $envio->fk_telefono=$telefono->codigo;
        $envio->save();
        
        $contar = DB::table('cliente as c')
        ->join('envio as e', 'c.id', '=', 'e.fk_cliente_envia')
        ->where('c.id', '=', $envio->fk_cliente_envia)
        ->count();

        $cliente = Cliente::findOrFail($envio->fk_cliente_envia);

        if ($contar > 4) {
            $cliente->l_vip = 'Si';
            $cliente->update();
        }

    	return Redirect::to('envio/paquete');	
    }

    public function show($id){
		return view("envio.envio.show",["envios"=>Envio::findOrFail($id)]);
    }

    public function edit($id){
        $envio=Envio::findOrFail($id);
        $telefono=DB::table('telefono as t')->where('t.codigo', '=', $envio->fk_telefono)->get();
        return view("envio.enviar.edit",["envio"=>$envio, "telefono"=>$telefono]);
    }

    public function update(EnvioFormRequest $request, $id){
        $envio=Envio::findOrFail($id);
        $envio->nombre_recibe=$request->get('nombre_recibe');
        $envio->apellido_recibe=$request->get('apellido_recibe');
        $envio->email_recibe=$request->get('email_recibe');
        $envio->update();

        $telefono=Telefono::findOrFail($envio->fk_telefono);
        $telefono->numero=$request->get('telefono');
        $telefono->update();

        return Redirect::to('envio/enviar');    
    }    

    public function destroy($id){
        $envio = Envio::findOrFail($id);
        $envio->delete();
        $telefono=DB::table('telefono')->where('codigo', '=', $envio->fk_telefono)->delete();
        
        return Redirect::to('envio/enviar'); 
    } 
}
