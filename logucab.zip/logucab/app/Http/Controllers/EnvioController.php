<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\Envio;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\EnvioFormRequest;
use DB;

class EnvioController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$envios=DB::table('envio as e');
    		return view('envio.envio.index', ["envios"=>$envios]);
    	}
    }

    public function create(){
    	return view("envio.envio.create");
    }

    public function store(PaqueteFormRequest $request){
    	$envio=new Envio;
    	$envio->cantidad_paquete=1;    	
    	$paquete->largo=$request->get('largo');
    	$paquete->ancho=$request->get('ancho');
    	$paquete->alto=$request->get('alto');
    	$paquete->fk_tipopaquete=$request->get('fk_tipopaquete');
    	$paquete->save();
    	return Redirect::to('envio/paquete');	
    }

    public function show($id){
		return view("envio.envio.show",["envios"=>Envio::findOrFail($id)]);
    }
}
