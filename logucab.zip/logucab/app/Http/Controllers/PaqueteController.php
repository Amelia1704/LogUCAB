<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\Paquete;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\PaqueteFormRequest;
use DB;
class PaqueteController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$paquetes=DB::table('paquete as p')
    		->join('tipopaquete as t', 'p.fk_tipopaquete', '=', 't.codigo')
    		->select('p.codigo', 'p.peso', 'p.largo', 'p.ancho','p.alto', 't.nombre as tipo')
            ->where('p.codigo','LIKE','%'.$query.'%')         
	   		->orderBy('p.codigo', 'asc')
    		->paginate(7);
    		return view('envio.paquete.index', ["paquetes"=>$paquetes, "searchText"=>$query]);
    	}
    }

    public function create(){
        $tipo=DB::table('tipopaquete')->get();
    	return view("envio.paquete.create",["tipo"=>$tipo]);
    }

    public function store(PaqueteFormRequest $request){
    	$paquete=new Paquete;
    	$paquete->peso=$request->get('peso');    	
    	$paquete->largo=$request->get('largo');
    	$paquete->ancho=$request->get('ancho');
    	$paquete->alto=$request->get('alto');
    	$paquete->fk_tipopaquete=$request->get('fk_tipopaquete');
    	$paquete->save();
    	return Redirect::to('envio/paquete');	
    }

    public function show($id){
		return view("envio.paquete.show",["paquete"=>Paquete::findOrFail($id)]);
    }

    public function edit($id){
        $paquete=Paquete::findOrFail($id);
        $tipopaquete=DB::table('tipopaquete')->get();
        return view("envio.paquete.edit",["paquete"=>$paquete, "tipopaquete"=>$tipopaquete]);
    }

    public function update(PaqueteFormRequest $request, $id){
    	$paquete=Paquete::findOrFail($id);
    	$paquete->peso=$request->get('peso');    	
    	$paquete->largo=$request->get('largo');
    	$paquete->ancho=$request->get('ancho');
    	$paquete->alto=$request->get('alto');
    	$paquete->fk_tipopaquete=$request->get('fk_tipopaquete');
    	$paquete->update();
    	return Redirect::to('envio/paquete');	
    }
}
