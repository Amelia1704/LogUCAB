<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use Illuminate\Support\Facades\Redirect;
use DB;

class PuertoController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
        if ($request){
            $query=trim($request->get('searchText'));
            $puertos=DB::table('puerto as p')
            ->join('sucursal as s', 'p.fk_sucursal', '=', 's.codigo')
            ->select('p.codigo', 'p.nombre', 'p.puestos_atraque', 'p.cantidad_muelles', 'p.longitud', 'p.ancho', 'p.calado', 'p.uso', 's.nombre as sucursal')
            ->where('p.codigo','LIKE','%'.$query.'%')      
            ->orderBy('p.codigo', 'asc')
            ->paginate(7);
            return view('sucursal.puerto.index', ["puertos"=>$puertos, "searchText"=>$query]);
        }
    }
}
