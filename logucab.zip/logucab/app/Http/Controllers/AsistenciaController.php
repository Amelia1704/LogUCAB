<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\asistencia;
use logUcab\empleado;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\AsistenciaFormRequest;
use DB;

class AsistenciaController extends Controller
{
	public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
            $query=trim($request->get('searchText'));

            $asistencias=DB::table('asistencia as a')
            ->join('empleado as e', 'e.id', '=', 'a.fk_empleado')
            ->select('e.nombre', 'a.fecha', 'a.codigo')
            ->orderBy('e.id', 'desc')
            ->paginate(7);

            return view('empleado.asistencia.index', ["asistencias"=>$asistencias, 
            "searchText"=>$query]);
        }
    }

    public function create(){
    	$empleado=DB::table('empleado')->get();
    	return view("empleado.asistencia.create",["empleado"=>$empleado]);
    }

    public function store(AsistenciaFormRequest $request){
    	$asistencia=new Asistencia;
    	$asistencia->fecha=$request->get('fecha');
    	$asistencia->fk_empleado=$request->get('fk_empleado');
    	$asistencia->save();
        
    	return Redirect::to('empleado/asistencia');	
    }

    public function edit($id){
        $asistencia=Asistencia::findOrFail($id);
        $empleado=Empleado::findOrFail($asistencia->fk_empleado);
        return view("empleado.asistencia.edit",["asistencia"=>$asistencia, "empleado"=>$empleado]);
    }

    public function update(AsistenciaFormRequest $request, $id){
    	$asistencia=Asistencia::findOrFail($id);
		$asistencia->fecha=$request->get('fecha');    	
    	$asistencia->update();
    	return Redirect::to('empleado/asistencia');	
    }    

    public function destroy($id){

    	$asistencia = Asistencia::findOrFail($id);
		$asistencia->delete();
    	return Redirect::to('empleado/asistencia');	
    }
}
