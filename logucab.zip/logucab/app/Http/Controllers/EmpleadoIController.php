<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\empleado;
use Illuminate\Support\Facades\Redirect;
use DB;

class EmpleadoIController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
        if ($request){
            $query=trim($request->get('searchText'));
            $empleados=DB::table('empleado as e')
            ->join('lugar as l', 'e.fk_lugar', '=', 'l.codigo')
            ->join('sucursal as s', 'e.fk_sucursal', '=', 's.codigo')
            ->join('telefono as t', 'e.id', '=', 't.fk_empleado')
            ->select('e.id', 'e.cedula', 'e.nombre', 'e.apellido', 't.numero as telefono','e.email_personal', 'email_empresa',
            'e.fecha_nac','e.nivel_academico','e.profesion','e.estado_civil','e.numero_hijos', 'e.salario',
            'e.fecha_ingreso', 'e.fecha_egreso', 'e.activo','l.nombre as lugar', 's.nombre as sucursal')
            ->where('e.activo', '=', 'No')
            ->where('e.cedula','LIKE','%'.$query.'%')      
            ->orderBy('e.id', 'desc')
            ->paginate(7);
            return view('empleado.inactivo.index', ["empleados"=>$empleados, "searchText"=>$query]);
        }
    }
}
