<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;
use logUcab\Http\Requests;
use logUcab\taller;
use logUcab\sucursal;
use logUcab\transporte;
use Illuminate\Support\Facades\Redirect;
use DB;

class TallerController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));

            
            $flota=DB::table('transporte_servicio as ts')
            ->join('transporte as t' ,'t.codigo', '=', 'ts.codigo')
            ->join('sucursal as s' ,'s.codigo', '=', 't.codigo')
            ->select('t.serial_motor as flota', 'ts.fecha_entrega as ultima_revision', 'ts.fecha_proxima as proxima_revision', 's.nombre as sucursal')
			->paginate(7);

    		return view('transporte.taller.index', ["flota"=>$flota, "searchText"=>$query]);
    	}
    }
}
