<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\empleado;
use logUcab\horario;
use logUcab\telefono;
use logUcab\empleado_horario;
use logUcab\empleado_zona;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\EmpleadoFormRequest;
use DB;

class EmpleadoController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
        if ($request){
            $query=trim($request->get('searchText'));
            $empleados=DB::table('empleado as e')
            ->join('lugar as l', 'e.fk_lugar', '=', 'l.codigo')
            ->join('sucursal as s', 'e.fk_sucursal', '=', 's.codigo')
            ->join('telefono as t', 'e.id', '=', 't.fk_empleado')
            ->join('empleado_zona as ez', 'e.id', '=', 'ez.fk_empleado')
            ->join('zona as z', 'z.codigo', '=', 'ez.fk_zona')            
            ->select('e.id', 'e.cedula', 'e.nombre', 'e.apellido', 't.numero as telefono','e.email_personal', 'email_empresa',
            'e.fecha_nac','e.nivel_academico','e.profesion','e.estado_civil','e.numero_hijos', 'e.salario',
            'e.fecha_ingreso','e.activo','l.nombre as lugar', 's.nombre as sucursal' , 'z.tipo as zona')
            ->where('e.cedula','LIKE','%'.$query.'%') 
            ->where('e.activo', '=', 'Si')        
            ->orderBy('e.id', 'desc')
            ->paginate(7);

            $asistencias=DB::table('asistencia as a')
            ->join('empleado as e', 'e.id', '=', 'a.fk_empleado')
            ->select('e.nombre', 'a.fecha')
            ->orderBy('e.id', 'desc')
            ->paginate(7);

            return view('empleado.activo.index', ["empleados"=>$empleados, "asistencias"=>$asistencias, 
            "searchText"=>$query]);
        }
    }

    public function create(){
        $lugar=DB::table('lugar')->where('tipo', '=', 'Parroquia')->get();
        $sucursal=DB::table('sucursal')->get();
        $zona=DB::table('zona')->get();
        return view("empleado.activo.create",["lugar"=>$lugar, "sucursal"=>$sucursal, "zona"=>$zona]);
    }

    public function store(EmpleadoFormRequest $request){
        $empleado=new Empleado;
        $empleado->cedula=$request->get('cedula');      
        $empleado->nombre=$request->get('nombre');
        $empleado->apellido=$request->get('apellido');
        $empleado->email_personal=$request->get('email_personal');
        $empleado->email_empresa=$request->get('email_empresa');
        $empleado->fecha_nac=$request->get('fecha_nac');
        $empleado->nivel_academico=$request->get('nivel_academico');
        $empleado->profesion=$request->get('profesion');
        $empleado->estado_civil=$request->get('estado_civil');
        $empleado->numero_hijos=$request->get('numero_hijos');
        $empleado->salario=$request->get('salario');
        $empleado->fecha_ingreso=$request->get('fecha_ingreso');
        $empleado->activo="Si";
        $empleado->fk_lugar=$request->get('fk_lugar');
        $empleado->fk_sucursal=$request->get('fk_sucursal');
        $empleado->save();

        $telefono = new Telefono;
        $telefono->numero = $request->get('numero');
        $telefono->tipo = 'Móvil';
        $telefono->fk_empleado = $empleado->id;
        $telefono->save();

        $empleado_zona = new empleado_zona;
        $empleado_zona->fk_zona= $request->get('zona');
        $empleado_zona->descripcion = 'Empleado asignado a la zona';
        $empleado_zona->fk_empleado = $empleado->id;
        $empleado_zona->save();           

        return Redirect::to('empleado/activo'); 
    }

    public function show($id){
        return view("empleado.activo.show",["empleado"=>Empleado::findOrFail($id)]);
    }

    public function edit($id){
        $empleado=Empleado::findOrFail($id);
        $lugar=DB::table('lugar')->where('tipo', '=', 'Parroquia')->get();
        $sucursal=DB::table('sucursal')->get();
        $telefono=DB::table('telefono as t')->where('t.fk_empleado', '=', $id)->get();
        $zona=DB::table('zona')->get();
        return view("empleado.activo.edit",["empleado"=>$empleado, "lugar"=>$lugar, 
        "sucursal"=>$sucursal, "telefono"=>$telefono, "zona"=>$zona]);
    }

    public function update(EmpleadoFormRequest $request, $id){
        $empleado=Empleado::findOrFail($id);
        $empleado->cedula=$request->get('cedula');      
        $empleado->nombre=$request->get('nombre');
        $empleado->apellido=$request->get('apellido');
        $empleado->email_personal=$request->get('email_personal');
        $empleado->email_empresa=$request->get('email_empresa');
        $empleado->fecha_nac=$request->get('fecha_nac');
        $empleado->nivel_academico=$request->get('nivel_academico');
        $empleado->profesion=$request->get('profesion');
        $empleado->estado_civil=$request->get('estado_civil');
        $empleado->numero_hijos=$request->get('numero_hijos');
        $empleado->salario=$request->get('salario');
        $empleado->fecha_ingreso=$request->get('fecha_ingreso');
        $empleado->activo=$request->get('activo');
        $empleado->fecha_egreso=$request->get('fecha_egreso');
        $empleado->fk_lugar=$request->get('fk_lugar');
        $empleado->fk_sucursal=$request->get('fk_sucursal');
        $empleado->update();

        $telefono=DB::table('telefono as t')->where('t.fk_empleado', '=', $id)->delete();
        $telefono = new Telefono;
        $telefono->numero = $request->get('telefono');
        $telefono->tipo = 'Móvil';
        $telefono->fk_empleado = $empleado->id;
        $telefono->save();

        $empleado_zona=DB::table('empleado_zona as ez')->where('ez.fk_empleado', '=', $id)->delete();
        $empleado_zona = new empleado_zona;
        $empleado_zona->fk_zona= $request->get('zona');
        $empleado_zona->descripcion = 'Empleado asignado a la zona';
        $empleado_zona->fk_empleado = $empleado->id;
        $empleado_zona->save();           


        return Redirect::to('empleado/activo');
    }    

    public function destroy($id){

        $empleado = Empleado::findOrFail($id);
        $empleado->activo='No';
        $empleado->fecha_egreso = '17-01-2018';
        $empleado->update();  
        return Redirect::to('empleado/activo');
    }
}
