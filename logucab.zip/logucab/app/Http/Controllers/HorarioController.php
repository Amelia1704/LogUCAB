<?php

namespace logUcab\Http\Controllers;

use Illuminate\Http\Request;

use logUcab\Http\Requests;
use logUcab\empleado;
use logUcab\horario;
use logUcab\empleado_horario;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\HorarioFormRequest;
use DB;

class HorarioController extends Controller
{
	public function __construct(){

    }

    public function index(Request $request){

    	if ($request){
    		$query=trim($request->get('searchText'));
    		$horarios=DB::table('horario as h')
    		->join('empleado_horario as eh', 'h.codigo', '=', 'eh.fk_horario')
    		->select('h.codigo', 'h.dia', 'h.hora_entrada', 'h.hora_salida')      
	   		->orderBy('h.codigo', 'desc')
    		->paginate(7);
    		return view('empleado.horario.index', ["horarios"=>$horarios, "searchText"=>$query]);
    	}
    }

    public function create(){
    	$empleado=DB::table('empleado')->get();
    	return view("empleado.horario.create",["empleado"=>$empleado]);
    }

    public function store(HorarioFormRequest $request){
		$horario = new Horario;
        $horario->dia = 'Lunes';
        $horario->hora_entrada = $request->get('hora_entrada1');
        $horario->hora_salida = $request->get('hora_salida1');
        $horario->save();

        $empleado_horario = new Empleado_Horario;
    	$empleado_horario->detalle = 'hola';
    	$empleado_horario->fk_empleado = $request->get('fk_empleado');
        $empleado_horario->fk_horario = $horario->codigo;
        $empleado_horario->save();

      	$horario = new Horario;
        $horario->dia = 'Martes';
        $horario->hora_entrada = $request->get('hora_entrada2');
        $horario->hora_salida = $request->get('hora_salida2');
        $horario->save();

        $empleado_horario = new Empleado_Horario;
    	$empleado_horario->detalle = 'hola';
    	$empleado_horario->fk_empleado = $request->get('fk_empleado');
        $empleado_horario->fk_horario = $horario->codigo;
        $empleado_horario->save();

        $horario = new Horario;
        $horario->dia = 'Miercoles';
        $horario->hora_entrada = $request->get('hora_entrada3');
        $horario->hora_salida = $request->get('hora_salida3');
        $horario->save();

        $empleado_horario = new Empleado_Horario;
    	$empleado_horario->detalle = 'hola';
    	$empleado_horario->fk_empleado = $request->get('fk_empleado');
        $empleado_horario->fk_horario = $horario->codigo;
        $empleado_horario->save();

        $horario = new Horario;
        $horario->dia = 'Jueves';
        $horario->hora_entrada = $request->get('hora_entrada4');
        $horario->hora_salida = $request->get('hora_salida4');
        $horario->save();

        $empleado_horario = new Empleado_Horario;
    	$empleado_horario->detalle = 'hola';
    	$empleado_horario->fk_empleado = $request->get('fk_empleado');
        $empleado_horario->fk_horario = $horario->codigo;
        $empleado_horario->save();

        $horario = new Horario;
        $horario->dia = 'Viernes';
        $horario->hora_entrada = $request->get('hora_entrada5');
        $horario->hora_salida = $request->get('hora_salida5');
        $horario->save(); 

        $empleado_horario = new Empleado_Horario;
    	$empleado_horario->detalle = 'hola';
    	$empleado_horario->fk_empleado = $request->get('fk_empleado');
        $empleado_horario->fk_horario = $horario->codigo;
        $empleado_horario->save();

    	return Redirect::to('empleado/activo');	
    }

    public function show($codigo){
    	$horarios=DB::table('horario as h')
    	->join('empleado_horario as eh', 'h.codigo', '=', 'eh.fk_horario')
    	->select('h.codigo', 'h.dia', 'h.hora_entrada', 'h.hora_salida')   
    	->where('eh.fk_empleado', '=', $codigo)   
	   	->orderBy('h.codigo', 'asc')
    	->paginate(7);
		return view('empleado.horario.show', ["horarios"=>$horarios]);
    }

    public function edit($codigo){
        $horario=Horario::findOrFail($codigo);
        return view("empleado.horario.edit",["horario"=>$horario]);
    }

    public function update(HorarioFormRequest $request, $codigo){
    	$horario=Horario::findOrFail($codigo);    	
    	$horario->hora_entrada=$request->get('hora_entrada');
    	$horario->hora_salida=$request->get('hora_salida');
    	$horario->update();
        return Redirect::to('empleado/activo');	
    }    


}
