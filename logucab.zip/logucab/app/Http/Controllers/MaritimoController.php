<?php

namespace logUcab\Http\Controllers;
use Illuminate\Http\Request;

use logUcab\Http\Requests;

use logUcab\maritimo;
use Illuminate\Support\Facades\Redirect;
use logUcab\Http\Requests\MaritimoFormRequest;
use DB;


class MaritimoController extends Controller
{
    public function __construct(){

    }

    public function index(Request $request){
    	if ($request){
    		$query=trim($request->get('searchText'));
    		$maritimos=DB::table('transporte as t')
    		->join('sucursal as s', 't.fk_sucursal', '=', 's.codigo')
    		->select('t.codigo', 't.clasificacion', 't.capacidad_carga', 't.serial_motor','t.matricula', 't.marca', 't.modelo', 't.fecha_vehiculo', 't.peso', 't.descripcion', 't.tipo', 's.nombre as sucursal')
            ->where('t.clasificacion', '=', 'Marítimo')
            ->where('t.codigo','LIKE','%'.$query.'%')
	   		->orderBy('t.codigo', 'desc')
    		->paginate(7);
    		return view('transporte.maritimo.index', ["maritimos"=>$maritimos, "searchText"=>$query]);
    	}
    }

    public function create(){
        $sucursal=DB::table('sucursal')->get();
    	return view("transporte.maritimo.create",["sucursal"=>$sucursal]);
    }

    public function store(MaritimoFormRequest $request){
    	$transporte=new Maritimo;	
    	$transporte->clasificacion='Marítimo';
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->peso=$request->get('peso');
    	$transporte->descripcion=$request->get('descripcion');
    	$transporte->tipo='Barco';
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->save();
    	return Redirect::to('transporte/maritimo');	
    }

    public function show($id){
		return view("transporte.maritimo.show",["transporte"=>Maritimo::findOrFail($id)]);
    }

    public function edit($id){
        $transporte=Maritimo::findOrFail($id);
        $sucursal=DB::table('sucursal')->get();
        return view("transporte.maritimo.edit",["transporte"=>$transporte, "sucursal"=>$sucursal]);
    }

    public function update(MaritimoFormRequest $request, $id){
    	$transporte=Maritimo::findOrFail($id);
    	$transporte->capacidad_carga=$request->get('capacidad_carga');
    	$transporte->serial_motor=$request->get('serial_motor');
    	$transporte->matricula=$request->get('matricula');
    	$transporte->marca=$request->get('marca');
    	$transporte->modelo=$request->get('modelo');
    	$transporte->fecha_vehiculo=$request->get('fecha_vehiculo');
    	$transporte->peso=$request->get('peso');
    	$transporte->descripcion=$request->get('descripcion');
    	$transporte->fk_sucursal=$request->get('fk_sucursal');
    	$transporte->update();
    	return Redirect::to('transporte/maritimo');	
    }

    public function destroy($id){

    	$maritimo = Maritimo::findOrFail($id);
		$maritimo->delete();
    	return Redirect::to('transporte/maritimo');	
    } 
}
