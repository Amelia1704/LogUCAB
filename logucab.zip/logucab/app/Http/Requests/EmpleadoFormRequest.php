<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EmpleadoFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cedula' => 'required|numeric',
            'nombre' => 'required|max:60',
            'apellido' => 'required|max:60',
            'email_personal' => 'required|max:60',
            'email_empresa' => 'required|max:60',
            'fecha_nac' => 'required|max:60',
            'nivel_academico' => 'required|max:60',
            'profesion' => 'required|max:60',
            'estado_civil' => 'required|max:60',
            'numero_hijos' => 'required|max:60',
            'fecha_ingreso' => 'required|max:60',
            'fk_lugar' => 'required',
        ];
    }
}
