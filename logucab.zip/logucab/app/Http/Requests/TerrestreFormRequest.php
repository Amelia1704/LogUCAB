<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TerrestreFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'capacidad_carga' => 'required|numeric',
            'serial_motor' => 'required|max:30',
            'matricula' => 'required|max:30',
            'marca' => 'required|max:30',
            'modelo' => 'required|max:30',
            'fecha_vehiculo' => 'required|max:30',
            'serial_carroceria' => 'max:30',
            'tipo' => 'max:30',
            'fk_sucursal' => 'required',        
        ];
    }
}
