<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UsuarioFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre' => 'required|max:30',
            'contraseña' => 'required|max:30',
            'fk_cliente' => 'numeric',
            'fk_empleado' => 'numeric',
            'fk_rol' => 'required',
        ];
    }
}
