<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AereoFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'capacidad_carga' => 'required|numeric',
            'serial_motor' => 'required|max:30',
            'matricula' => 'required|max:30',
            'marca' => 'required|max:30',
            'modelo' => 'required|max:30',
            'fecha_vehiculo' => 'required|max:30',
            'longitud' => 'numeric',
            'envergadura' => 'numeric',
            'area' => 'numeric',
            'altura' => 'numeric',
            'ancho_cabina' => 'numeric',
            'diametro_fuselaje' => 'numeric',
            'peso_vacio' => 'numeric',
            'peso_maximo' => 'numeric',
            'carrera_despeje' => 'max:30',
            'velocidad_maxima' => 'numeric',
            'capacidad_combustible' => 'numeric',
            'cantidad_motor' => 'numeric',
            'fk_sucursal' => 'required',
        ];
    }
}
