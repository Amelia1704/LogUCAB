<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class HorarioFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'hora_entrada1' => 'max:30',
            'hora_salida1' => 'max:30',
            'hora_entrada2' => 'max:30',
            'hora_salida2' => 'max:30',
            'hora_entrada3' => 'max:30',
            'hora_salida3' => 'max:30',
            'hora_entrada4' => 'max:30',
            'hora_salida4' => 'max:30',
            'hora_entrada5' => 'max:30',
            'hora_salida5' => 'max:30',
        ];
    }
}