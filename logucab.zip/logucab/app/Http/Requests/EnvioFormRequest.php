<?php

namespace logUcab\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EnvioFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre_recibe' => 'required|max:60',
            'apellido_recibe' => 'required|max:60',
            'email_recibe' => 'required|max:60',
            'telefono' => 'required|max:60',
        ];
    }
}
