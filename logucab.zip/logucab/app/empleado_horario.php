<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class empleado_horario extends Model
{
    protected $table = 'empleado_horario';
    protected $primaryKey = 'clave';

    public $timestamps = false;

    protected $fillable = [
    	'detalle',
    	'fk_empleado',
    	'fk_horario',
    ];
    
    protected $guarded = [

    ]; 
}
