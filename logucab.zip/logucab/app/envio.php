<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class envio extends Model
{
    protected $table = 'envio';
    protected $primaryKey = 'numero';

    public $timestamps = false;

    protected $fillable = [
    	'cantidad_paquete',
    	'fk_cliente_envia',
    	'fk_cliente_recibe',
    	'telefono',
    	'fk_tipoenvio'
	 ];
    protected $guarded = [

    ]; 
}
