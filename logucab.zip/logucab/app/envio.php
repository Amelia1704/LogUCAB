<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class envio extends Model
{
    protected $table = 'envio';
    protected $primaryKey = 'numero';

    public $timestamps = false;

    protected $fillable = [
        'costo',
        'nombre_recibe',
        'apellido_recibe',
        'email_recibe',
    	'fk_cliente_envia',
    	'fk_telefono',
    	'fk_tipoenvio',
        'fk_paquete',
        'fk_ruta'

	 ];
    protected $guarded = [

    ]; 
}
