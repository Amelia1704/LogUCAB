<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class zona extends Model
{
    protected $table = 'zona';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'nombre',
    	'tipo',
    	'descripcion',
    	'dimension_area',
    	'fk_sucursal',
    ];
    
    protected $guarded = [

    ];
}
