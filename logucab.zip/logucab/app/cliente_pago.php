<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class cliente_pago extends Model
{
    protected $table = 'cliente_pago';
    protected $primaryKey = 'clave';

    public $timestamps = false;

    protected $fillable = [
    	'descripcion',
    	'fk_cliente',
    	'fk_pago',
    	'fk_reciboenvio'

    ];
    protected $guarded = [

    ];
}
