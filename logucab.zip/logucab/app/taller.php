<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class taller extends Model
{
    protected $table = 'transporte_servicio';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fecha_entrega',
    	'fecha_salida_prevista',
    	'fecha_proxima',
    	'fecha_salida_real',
    	'fk_transporte',
    	'fk_servicio',
    ];
    
    protected $guarded = [

    ]; 
}
