<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class ruta_transporte extends Model
{
    protected $table = 'ruta_transporte';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fk_ruta',
    	'fk_transporte',
    ];
    
    protected $guarded = [

    ]; 
}
