<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class accion_usuario extends Model
{
    protected $table = 'accion_usuario';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fecha',
    	'descripción',
    	'fk_accion',
    	'fk_usuario'

    ];
    protected $guarded = [

    ];
}
