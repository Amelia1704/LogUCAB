<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class estatus_envio extends Model
{
    protected $table = 'estatus_envio';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fk_estatus',
    	'fk_envio'
    ];
    
    protected $guarded = [

    ]; 
}
