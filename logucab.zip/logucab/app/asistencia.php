<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class asistencia extends Model
{
    protected $table = 'asistencia';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fecha',
    	'fk_empleado'

    ];
    protected $guarded = [

    ];
}
