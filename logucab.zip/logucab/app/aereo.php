<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class aereo extends Model
{
    protected $table = 'transporte';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'capacidad_carga',
    	'serial_motor',
    	'matricula',
    	'marca',
    	'modelo',
    	'fecha_vehiculo',
    	'longitud',
    	'envergadura',
    	'area',
    	'altura',
    	'ancho_cabina',
    	'diametro_fuselaje',
    	'peso_vacio',
    	'peso_maximo',
    	'carrera_despeje',
    	'velocidad_maxima',
    	'capacidad_combustible',
    	'cantidad_motor',
    	'fk_sucursal'

    ];
    protected $guarded = [

    ];    
}
