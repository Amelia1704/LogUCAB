<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class rol extends Model
{
    protected $table = 'rol';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'tipo',

    ];
    protected $guarded = [

    ];

}
