<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class telefono extends Model
{
    protected $table = 'telefono';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'numero',
    	'tipo',
    ];
    
    protected $guarded = [

    ]; 
}
