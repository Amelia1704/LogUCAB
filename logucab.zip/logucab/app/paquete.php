<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class paquete extends Model
{
    protected $table = 'paquete';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'peso',
    	'largo',
    	'ancho',
    	'alto',
        'fk_envio',
    	'fk_tipopaquete'
	 ];
    protected $guarded = [

    ];    
}
