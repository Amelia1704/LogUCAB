<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class servicio extends Model
{
    protected $table = 'servicio_sucursal';
    protected $primaryKey = 'clave';

    public $timestamps = false;

    protected $fillable = [
    	'fk_servicio',
    	'fk_sucursal'

    ];
    protected $guarded = [

    ];
}
