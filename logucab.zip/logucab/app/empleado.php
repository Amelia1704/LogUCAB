<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class empleado extends Model
{
    protected $table = 'empleado';
    protected $primaryKey = 'id';

    public $timestamps = false;

    protected $fillable = [
    	'cedula',
    	'nombre',
    	'apellido',
    	'email_personal',
    	'email_empresa',
    	'fecha_nac',
    	'nivel_academico',
    	'profesion',
    	'estado_civil',
    	'numero_hijos',
        'salario',
    	'fecha_ingreso',
    	'activo',
    	'fecha_egreso',
    	'fk_lugar',
        'fk_sucursal',
    ];
    
    protected $guarded = [

    ]; 
}
