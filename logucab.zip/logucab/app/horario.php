<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class horario extends Model
{
    protected $table = 'horario';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'dia',
    	'hora_entrada',
    	'hora_salida',
    ];
    
    protected $guarded = [

    ]; 
}
