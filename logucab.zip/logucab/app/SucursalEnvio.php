<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class SucursalEnvio extends Model
{
    protected $table = 'sucursal_envio';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'fecha_entrega',
    	'fk_sucursal'
	 ];
    protected $guarded = [

    ]; 
}
