<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class ruta extends Model
{
    protected $table = 'ruta';
    protected $primaryKey = 'id';

    public $timestamps = false;

    protected $fillable = [
    	'id',
    	'costo',
    	'duracion',
    	'fk_sucursal_origen',
    	'fk_sucursal_destino',
    ];
    
    protected $guarded = [

    ]; 
}
