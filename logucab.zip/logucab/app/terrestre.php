<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class terrestre extends Model
{
    protected $table = 'transporte';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'capacidad_carga',
    	'serial_motor',
    	'matricula',
    	'marca',
    	'modelo',
    	'fecha_vehiculo',
    	'serial_carroceria',
    	'fk_sucursal'

    ];
    protected $guarded = [

    ];
}
