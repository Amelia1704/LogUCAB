<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class usuario extends Model
{
    protected $table = 'usuario';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'nombre',
    	'contraseña',
    	'fk_cliente',
    	'fk_empleado',
    	'fk_rol'

    ];
    protected $guarded = [

    ];
}
