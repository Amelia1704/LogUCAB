<?php

namespace logUcab;

use Illuminate\Database\Eloquent\Model;

class tipopaquete extends Model
{
    protected $table = 'tipopaquete';
    protected $primaryKey = 'codigo';

    public $timestamps = false;

    protected $fillable = [
    	'nombre',
    	'costo'
	 ];
    protected $guarded = [

    ];    
}
