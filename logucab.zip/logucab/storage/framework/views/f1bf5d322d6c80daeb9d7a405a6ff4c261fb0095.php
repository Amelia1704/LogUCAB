<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo usuario</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'usuario/control', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>


		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre" class="form-control" placeholder="Nombre">	
		</div>	
		<div class="form-group">
			<label for="contraseña">Contraseña</label>
			<input type="text" name="contraseña" class="form-control" placeholder="Contraseña">
		</div>
		<div class="form-group">
			<label for="cliente">Cliente</label>
					<select name="fk_cliente" class="form-control">
						<?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($cli->id); ?>"><?php echo e($cli->nombre); ?> - <?php echo e($cli->cedula); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>		
		<div class="form-group">
			<label for="rol">Rol</label>
					<select name="fk_rol" class="form-control">
						<?php $__currentLoopData = $rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($r->codigo); ?>"><?php echo e($r->tipo); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>	
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>