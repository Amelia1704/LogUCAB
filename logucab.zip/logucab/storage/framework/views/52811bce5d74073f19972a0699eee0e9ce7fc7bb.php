
<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Cliente LVIP: <?php echo e($cliente->id); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel='stylesheet' href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Roboto+Condensed')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css1/style.css')); ?>">

  <div class="contact-area">
  <div class="contact">
    <main>
      <section>
        <div class="content">
          <img src="<?php echo e(asset('img/Logo.png')); ?>" height="70px" alt="Profile Image">

          <aside>
            <h1>Membresía L-VIP</h1>
					<?php  
        				$contar = DB::table('cliente as c')
                        ->where('c.l_vip', '=', 'Si')
                        ->count();	
                     ?>					
                        <?php for($x = 1; $x < $contar; $x++): ?>
						<?php endfor; ?>			
            <h1>ID:<?php echo e($sucursal->codigo); ?>-<?php echo e($cliente->cedula); ?>-00<?php echo e($x); ?></h1>
            <p>Nombre: <?php echo e($cliente->nombre); ?></p>
            <p>Apellido: <?php echo e($cliente->apellido); ?></p>
            <p>Cedula: <?php echo e($cliente->cedula); ?></p>
          </aside>
          
          <button>
            <span>Carnet</span>
            
            <svg xmlns="" width="48" height="48" viewBox="0 0 48 48"> <g class="nc-icon-wrapper" fill="#444444"> <path d="M14.83 30.83L24 21.66l9.17 9.17L36 28 24 16 12 28z"></path> </g> </svg>
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>