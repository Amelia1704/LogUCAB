
<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Vehículo: <?php echo e($transporte->codigo); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($transporte,['method'=>'PATCH', 'route'=>['terrestre.update', $transporte->codigo]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="clasificacion">Clasificación</label>
			<input type="text" name="clasificacion"required value="<?php echo e($transporte->clasificacion); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="capacidad_carga">Capacidad carga (m2)</label>
			<input type="text" name="capacidad_carga"required value="<?php echo e($transporte->capacidad_carga); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="serial_motor">Serial motor</label>
			<input type="text" name="serial_motor" required value="<?php echo e($transporte->serial_motor); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="matricula">Matrícula</label>
			<input type="text" name="matricula"required value="<?php echo e($transporte->matricula); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="marca">Marca</label>
			<input type="text" name="marca"required value="<?php echo e($transporte->marca); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="modelo">Modelo</label>
			<input type="text" name="modelo"required value="<?php echo e($transporte->modelo); ?>" class="form-control">
		</div>		
		<div class="form-group">
			<label for="fecha_vehiculo">Fecha Vehículo</label>
			<input type="text" name="fecha_vehiculo"required value="<?php echo e($transporte->fecha_vehiculo); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="serial_carroceria">Serial Carroceria</label>
			<input type="text" name="serial_carroceria"required value="<?php echo e($transporte->serial_carroceria); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="tipo">Tipo (Camion/Motocicleta)</label>
			<input type="text" name="tipo"required value="<?php echo e($transporte->tipo); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="fk_sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($suc->codigo==$transporte->fk_sucursal): ?>
						<option value="<?php echo e($suc->codigo); ?>" selected><?php echo e($suc->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>
		<div class="form-group">
			<a href="<?php echo e(URL::action('TerrestreController@index')); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>