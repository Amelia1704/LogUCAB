<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar tu envío: <?php echo e($paquete->codigo); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($paquete,['method'=>'PATCH', 'route'=>['paquete.update', $paquete->codigo]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="peso">Peso (KG)</label>
			<input type="text" name="peso"required value="<?php echo e($paquete->peso); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="largo">Largo</label>
			<input type="text" name="largo"required value="<?php echo e($paquete->largo); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="ancho">Ancho</label>
			<input type="text" name="ancho" required value="<?php echo e($paquete->ancho); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="alto">Alto</label>
			<input type="text" name="alto"required value="<?php echo e($paquete->alto); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="fk_tipopaquete">Tipo del paquete</label>
					<select name="fk_tipopaquete" class="form-control">
						<?php $__currentLoopData = $tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($tipo->codigo==$paquete->fk_tipopaquete): ?>
						<option value="<?php echo e($tipo->codigo); ?>" selected><?php echo e($tipo->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($tipo->codigo); ?>"><?php echo e($tipo->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>
		<div class="form-group">
			<a href="<?php echo e(URL::action('EnvioController@index')); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>