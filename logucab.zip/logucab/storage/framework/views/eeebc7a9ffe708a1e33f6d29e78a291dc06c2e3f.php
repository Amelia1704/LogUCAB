<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nuevo empleado</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'empleado/activo', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>


		<div class="form-group">
			<label for="cedula">Cédula</label>
			<input type="text" name="cedula" class="form-control" placeholder="Cedula">	
		</div>
		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre" class="form-control" placeholder="Nombre">	
		</div>
		<div class="form-group">
			<label for="apellido">Apellido</label>
			<input type="text" name="apellido" class="form-control" placeholder="Apellido">	
		</div>
		<div class="form-group">
			<label for="numero">Número de teléfono</label>
			<input type="text" name="numero" class="form-control" placeholder="+58">	
		</div>
		<div class="form-group">
			<label for="email_personal">Email Personal</label>
			<input type="text" name="email_personal" class="form-control" placeholder="Email Personal">	
		</div>
		<div class="form-group">
			<label for="email_empresa">Email Empresa</label>
			<input type="text" name="email_empresa" class="form-control" placeholder="Email Empresa">	
		</div>
		<div class="form-group">
			<label for="fecha_nac">Fecha de Nacimiento</label>
			<input type="date" name="fecha_nac" class="form-control" placeholder="Fecha de Nacimiento">	
		</div>	
		<div class="form-group">
			<label for="nivel_academico">Nivel Académico</label>
			<input type="text" name="nivel_academico" class="form-control" placeholder="Nivel Académico">
		</div>
		<div class="form-group">
			<label for="profesion">Profesión</label>
			<input type="text" name="profesion" class="form-control" placeholder="Profesion">	
		</div>	
		<div class="form-group">
			<label for="estado_civil">Estado civil</label>
			<select name="estado_civil" class="form-control">
				<option value="Soltero">Soltero</option>
				<option value="Casado">Casado</option>
				<option value="Divorciado">Divorciado</option>
				<option value="Viudo">Viudo</option>
			</select>	
		</div>			
	    <div class="form-group">
			<label for="numero_hijos">Número de Hijos</label>
			<input type="text" name="numero_hijos" class="form-control" placeholder="Número de Hijos">	
		</div>
		<div class="form-group">
			<label for="salario">Salario</label>
			<input type="text" name="salario" class="form-control" placeholder="Salario">	
		</div>
		<div class="form-group">
			<label for="fecha_ingreso">Fecha de Ingreso</label>
			<input type="date" name="fecha_ingreso" class="form-control" placeholder="Fecha de Ingreso">	
		</div>
		<div class="form-group">
			<label for="direccion">Direccion</label>
					<select name="fk_lugar" class="form-control">
						<?php $__currentLoopData = $lugar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($lug->codigo); ?>"><?php echo e($lug->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>	
		<div class="form-group">
			<label for="sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>
		<div class="form-group">
			<label for="zona">Zona</label>
					<select name="zona" class="form-control">
						<?php $__currentLoopData = $zona; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($z->codigo); ?>"><?php echo e($z->tipo); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>