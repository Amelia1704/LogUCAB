
<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Agregar nuevo cliente</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'cliente/lista', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="cedula">Cédula</label>
			<input type="text" name="cedula" class="form-control" placeholder="Cedula">	
		</div>
		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre" class="form-control" placeholder="Nombre">	
		</div>	
		<div class="form-group">
			<label for="apellido">Apellido</label>
			<input type="text" name="apellido" class="form-control" placeholder="Apellido">	
		</div>
		<div class="form-group">
			<label for="fecha_nac">Fecha de nacimiento</label>
			<input type="date" name="fecha_nac" class="form-control" placeholder="Fecha de nacimiento">	
		</div>	
		<div class="form-group">
			<label for="estado_civil">Estado civil</label>
			<select name="estado_civil" class="form-control">
				<option value="Soltero">Soltero</option>
				<option value="Casado">Casado</option>
				<option value="Divorciado">Divorciado</option>
				<option value="Viudo">Viudo</option>
			</select>	
		</div>			
		<div class="form-group">
			<label for="empresa">Empresa</label>
			<input type="text" name="empresa" class="form-control" placeholder="Empresa">
		</div>
		<div class="form-group">
			<label for="l_vip">Cliente L-VIP</label>
			<input type="text" name="l_vip" class="form-control" placeholder="Cliente L-VIP">	
		</div>	
		<div class="form-group">
			<label for="direccion">Direccion</label>
					<select name="fk_lugar" class="form-control">
						<?php $__currentLoopData = $lugar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($lug->codigo); ?>"><?php echo e($lug->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>	
		<div class="form-group">
			<label for="numero">Número de teléfono</label>
			<input type="text" name="numero" class="form-control" placeholder="+58">	
		</div>
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>