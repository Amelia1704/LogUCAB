<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Puertos LogUCAB <a href="mostrar/create"><button class="btn btn-success">Nuevo</button></a></h3>
	<?php echo $__env->make('sucursal.puerto.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>COD</td>
					<td>Nombre</td>
					<td>Puestos de atraque</td>
					<td>Cantidad de Muelles</td>
					<td>Longitud</td>
					<td>Ancho</td>
					<td>Calado</td>
					<td>Uso</td>
					<td>Sucursal</td>
				</thead>

				<?php $__currentLoopData = $puertos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($pue->codigo); ?></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><?php echo e($pue->nombre); ?></td>
					<td><?php echo e($pue->puestos_atraque); ?></td>
					<td><?php echo e($pue->cantidad_muelles); ?></td>
					<td><?php echo e($pue->longitud); ?></td>
					<td><?php echo e($pue->ancho); ?></td>
					<td><?php echo e($pue->calado); ?></td>
					<td><?php echo e($pue->uso); ?></td>
					<td><?php echo e($pue->sucursal); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<?php echo e($puertos->render()); ?>

			</table>
		</div>
		
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>