<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar un nuevo vehículo</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'transporte/aereo', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>



		</div>	
		<div class="form-group">
			<label for="capacidad_carga">Capacidad carga (m2)</label>
			<input type="text" name="capacidad_carga" class="form-control" placeholder="Capacidad carga">	
		</div>
		<div class="form-group">
			<label for="serial_motor">Serial motor</label>
			<input type="text" name="serial_motor" class="form-control" placeholder="Serial motor">	
		</div>	
		<div class="form-group">
			<label for="matricula">Matrícula</label>
			<input type="text" name="matricula" class="form-control" placeholder="Matricula">	
		</div>	
		<div class="form-group">
			<label for="marca">Marca</label>
			<input type="text" name="marca" class="form-control" placeholder="Marca">	
		</div>	
		<div class="form-group">
			<label for="modelo">Modelo</label>
			<input type="text" name="modelo" class="form-control" placeholder="Modelo">	
		</div>		
		<div class="form-group">
			<label for="fecha_vehiculo">Fecha Vehículo</label>
			<input type="date" name="fecha_vehiculo" class="form-control" placeholder="Fecha vehiculo">	
		</div>
		<div class="form-group">
			<label for="longitud">Longitud</label>
			<input type="text" name="longitud" class="form-control" placeholder="Longitud">	
		</div>		
		<div class="form-group">
			<label for="envergadura">Envergadura</label>
			<input type="text" name="envergadura" class="form-control" placeholder="Envergadura">	
		</div>	
		<div class="form-group">
			<label for="area">Área</label>
			<input type="text" name="area" class="form-control" placeholder="Area">	
		</div>	
		<div class="form-group">
			<label for="altura">Altura</label>
			<input type="text" name="altura" class="form-control" placeholder="Altura">	
		</div>	
		<div class="form-group">
			<label for="ancho_cabina">Ancho Cabina</label>
			<input type="text" name="ancho_cabina" class="form-control" placeholder="Ancho cabina">	
		</div>	
		<div class="form-group">
			<label for="diametro_fuselaje">Diametro Fuselaje</label>
			<input type="text" name="diametro_fuselaje" class="form-control" placeholder="Diamtro fuselaje">	
		</div>	
		<div class="form-group">
			<label for="peso_vacio">Peso vacío</label>
			<input type="text" name="peso_vacio" class="form-control" placeholder="Peso vacio">	
		</div>	
		<div class="form-group">
			<label for="peso_maximo">Peso máximo</label>
			<input type="text" name="peso_maximo" class="form-control" placeholder="Peso maximo">	
		</div>	
		<div class="form-group">
			<label for="carrera_despeje">Carrera despeje</label>
			<input type="text" name="carrera_despeje" class="form-control" placeholder="Carrera despeje">
		</div>	
		<div class="form-group">
			<label for="velocidad_maxima">Velocidad máxima</label>
			<input type="text" name="velocidad_maxima" class="form-control" placeholder="Velocidad maxima">	
		</div>	
		<div class="form-group">
			<label for="capacidad_combustible">Capacidad_combustible</label>
			<input type="text" name="capacidad_combustible" class="form-control" placeholder="Capacidad de combustible">	
		</div>	
		<div class="form-group">
			<label for="cantidad_motor">Cantidad motores</label>
			<input type="text" name="cantidad_motor" class="form-control" placeholder="Cantidad de motores">	
		</div>	
		<div class="form-group">
			<label for="sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>	

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>