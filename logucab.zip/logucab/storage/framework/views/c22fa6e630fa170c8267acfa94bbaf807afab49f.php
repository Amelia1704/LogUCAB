<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Empleado: <?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellido); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($empleado,['method'=>'PATCH', 'route'=>['activo.update', $empleado->id]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="cedula">Cédula</label>
			<input type="text" name="cedula" required value="<?php echo e($empleado->cedula); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre"required value="<?php echo e($empleado->nombre); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="apellido">Apellido</label>
			<input type="text" name="apellido"required value="<?php echo e($empleado->apellido); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="telefono">Número de Teléfono</label>
			<?php $__currentLoopData = $telefono; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<input type="text" name="telefono" required value="<?php echo e($t->numero); ?>" class="form-control">
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="form-group">
			<label for="email_personal">Email Personal</label>
			<input type="text" name="email_personal"required value="<?php echo e($empleado->email_personal); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="email_empresa">Email Empresa</label>
			<input type="text" name="email_empresa"required value="<?php echo e($empleado->email_empresa); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_nac">Fecha de nacimiento</label>
			<input type="text" name="fecha_nac" required value="<?php echo e($empleado->fecha_nac); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="nivel_academico">Nivel Académico</label>
			<input type="text" name="nivel_academico"required value="<?php echo e($empleado->nivel_academico); ?>" class="form-control">
		</div><div class="form-group">
			<label for="profesion">Profesión</label>
			<input type="text" name="profesion"required value="<?php echo e($empleado->profesion); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="estado_civil">Estado civil</label>
			<input type="text" name="estado_civil"required value="<?php echo e($empleado->estado_civil); ?>" class="form-control">
		</div>		
		<div class="form-group">
			<label for="numero_hijos">Número de Hijos</label>
			<input type="text" name="numero_hijos" required value="<?php echo e($empleado->numero_hijos); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="salario">Salario</label>
			<input type="text" name="salario" required value="<?php echo e($empleado->salario); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_ingreso">Fecha Ingreso</label>
			<input type="text" name="fecha_ingreso" required value="<?php echo e($empleado->fecha_ingreso); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="activo">Activo</label>
			<input type="text" name="activo"required value="<?php echo e($empleado->activo); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="fecha_egreso">Fecha de Egreso</label>
			<input type="text" name="fecha_egreso" class="form-control">
		</div>
		<div class="form-group">
			<label for="fk_lugar">Direccion</label>
					<select name="fk_lugar" class="form-control">
						<?php $__currentLoopData = $lugar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($lug->codigo==$empleado->fk_lugar): ?>
						<option value="<?php echo e($lug->codigo); ?>" selected><?php echo e($lug->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($lug->codigo); ?>"><?php echo e($lug->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>	
		<div class="form-group">
			<label for="fk_sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($suc->codigo==$empleado->fk_sucursal): ?>
						<option value="<?php echo e($suc->codigo); ?>" selected><?php echo e($suc->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>

		<div class="form-group">
			<a href="<?php echo e(URL::action('EmpleadoController@index')); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>