<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Envíos <a href="ver/create"><button class="btn btn-success">Agregar</button></a></h3>
	<?php echo $__env->make('envio.enviar.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>#</center></td>
					<td><center>Costo</center></td>
					<td><center>Cliente que envía</center></td>
					<td><center>Nombre de la persona que recibe</center></td>
					<td><center>Apellido de la persona que recibe</center></td>
					<td><center>Email de la persona que recibe</center></td>
					<td><center>Teléfono de la persona que recibe</center></td>
					<td><center>Paquete</center></td>
					<td><center>Tipo de Envío</center></td>
					<td><center>Ruta</center></td>
				</thead>

				<?php $__currentLoopData = $envios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $env): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($env->numero); ?></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><?php echo e($env->costo); ?></td>
					<td><?php echo e($env->cliente_envia); ?></td>
					<td><?php echo e($env->nombre_recibe); ?></td>
					<td><?php echo e($env->apellido_recibe); ?></td>
					<td><?php echo e($env->email_recibe); ?></td>
					<td><?php echo e($env->telefono); ?></td>
					<td><?php echo e($env->fk_paquete); ?></td>
					<td><?php echo e($env->tipoenvio); ?></td>
					<td><?php echo e($env->fk_ruta); ?></td>
					<td>
						<td><a href="<?php echo e(URL::action('EnvioController@edit',$env->numero)); ?>"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-<?php echo e($env->numero); ?>" data-toggle="modal"><button class="btn btn-danger">Cancelar</button></a></td>
					</td>
				</tr>
				<?php echo $__env->make('envio.enviar.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($envios->render()); ?>


		<h4>Listado de paquetes con todos los cambios de estatus indicando las fechas de cambio</h4>
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>Fecha</td>
					<td>Estatus</td>
					<td>Envio</td>
				</thead>

				<?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($r->fecha); ?></td>
					<td><?php echo e($r->Estatus); ?></td>
					<td><?php echo e($r->Envio); ?></td> 
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<?php echo e($reportes->render()); ?>

		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>