<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Horario: </h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($horario,['method'=>'PATCH', 'route'=>['horario.update', $horario->codigo]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="hora_entrada">Hora de entrada</label>
			<input type="text" name="hora_entrada" required value="<?php echo e($horario->hora_entrada); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="hora_salida">Hora de salida</label>
			<input type="text" name="hora_salida"required value="<?php echo e($horario->hora_salida); ?>" class="form-control">
		</div>	
		
		<div class="form-group">
			<a href="<?php echo e(URL::action('HorarioController@show',$horario->codigo)); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>