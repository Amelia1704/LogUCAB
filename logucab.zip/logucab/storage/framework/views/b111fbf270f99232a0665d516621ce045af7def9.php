<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Sucursal: <?php echo e($sucursal->nombre); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($sucursal,['method'=>'PATCH', 'route'=>['ver.update', $sucursal->codigo]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="text" name="nombre"required value="<?php echo e($sucursal->nombre); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="capacidad">Capacidad (m2)</label>
			<input type="text" name="capacidad"required value="<?php echo e($sucursal->capacidad); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="telefono">Número de Teléfono</label>
			<?php $__currentLoopData = $telefono; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<input type="text" name="telefono" required value="<?php echo e($t->numero); ?>" class="form-control">
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="form-group">
			<label for="email">Email</label>
			<input type="text" name="email" required value="<?php echo e($sucursal->email); ?>" class="form-control">
		</div>	
		<div class="form-group">
			<label for="capacidad_almacenamiento">Capacidad de almacenamiento</label>
			<input type="text" name="capacidad_almacenamiento"required value="<?php echo e($sucursal->capacidad_almacenamiento); ?>" class="form-control">
		</div>		
		<div class="form-group">
			<label for="fk_lugar">Direccion</label>
					<select name="fk_lugar" class="form-control">
						<?php $__currentLoopData = $lugar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($lug->codigo==$sucursal->fk_lugar): ?>
						<option value="<?php echo e($lug->codigo); ?>" selected><?php echo e($lug->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($lug->codigo); ?>"><?php echo e($lug->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>
		<div class="form-group">
			<label for="fk_personacontacto">Contacto</label>
					<select name="fk_personacontacto" class="form-control">
						<?php $__currentLoopData = $personacontacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($per->id==$sucursal->fk_personacontacto): ?>
						<option value="<?php echo e($per->id); ?>" selected><?php echo e($per->cedula); ?></option><?php else: ?>
						<option value="<?php echo e($per->id); ?>"><?php echo e($per->cedula); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>	

		<div class="form-group">
			<a href="<?php echo e(URL::action('SucursalController@index')); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>