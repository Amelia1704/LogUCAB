
<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Transportes Aéreos <a href="aereo/create"><button class="btn btn-success">Agregar</button></a></h3>
	<?php echo $__env->make('transporte.aereo.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>COD</center></td>
					<td><center>Capacidad carga (m2)</center></td>
					<td><center>Serial motor</center></td>
					<td><center>Matrícula</center></td>
					<td><center>Marca</center></td>
					<td><center>Modelo</center></td>
					<td><center>Fecha Vehículo</center></td>
					<td><center>Longitud</center></td>
					<td><center>Envergadura</center></td>
					<td><center>Área</center></td>
					<td><center>Altura</center></td>
					<td><center>Ancho Cabina</center></td>
					<td><center>Diametro Fuselaje</center></td>
					<td><center>Peso vacío</center></td>
					<td><center>Peso máximo</center></td>
					<td><center>Carrera despeje</center></td>
					<td><center>Velocidad máxima</center></td>
					<td><center>Capacidad combustible</center></td>
					<td><center>Cantidad motores</center></td>
					<td><center>Sucursal</center></td>

				</thead>

				<?php $__currentLoopData = $aereos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aereo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($aereo->codigo); ?></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><?php echo e($aereo->capacidad_carga); ?></td>
					<td><?php echo e($aereo->serial_motor); ?></td>
					<td><center><?php echo e($aereo->matricula); ?></center></td>
					<td><?php echo e($aereo->marca); ?></td>
					<td><?php echo e($aereo->modelo); ?></td>
					<td><?php echo e($aereo->fecha_vehiculo); ?></td>
					<td><?php echo e($aereo->longitud); ?></td>
					<td><?php echo e($aereo->envergadura); ?></td>
					<td><?php echo e($aereo->area); ?></td>
					<td><?php echo e($aereo->altura); ?></td>
					<td><?php echo e($aereo->ancho_cabina); ?></td>
					<td><?php echo e($aereo->diametro_fuselaje); ?></td>
					<td><?php echo e($aereo->peso_vacio); ?></td>
					<td><?php echo e($aereo->peso_maximo); ?></td>
					<td><?php echo e($aereo->carrera_despeje); ?></td>
					<td><?php echo e($aereo->velocidad_maxima); ?></td>
					<td><?php echo e($aereo->capacidad_combustible); ?></td>
					<td><?php echo e($aereo->cantidad_motor); ?></td>
					<td><?php echo e($aereo->sucursal); ?></td>
					<td>
						<td><a href="<?php echo e(URL::action('AereoController@edit',$aereo->codigo)); ?>"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-<?php echo e($aereo->codigo); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a></td>
					</td>
				</tr>
				<?php echo $__env->make('transporte.aereo.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($aereos->render()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>