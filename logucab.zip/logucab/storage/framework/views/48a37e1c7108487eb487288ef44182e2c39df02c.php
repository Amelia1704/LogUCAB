<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Transportes Marítimos <a href="maritimo/create"><button class="btn btn-success">Agregar</button></a></h3>
	<?php echo $__env->make('transporte.maritimo.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td><center>COD</center></td>
					<td><center>Capacidad carga (m2)</center></td>
					<td><center>Serial motor</center></td>
					<td><center>Matrícula</center></td>
					<td><center>Marca</center></td>
					<td><center>Modelo</center></td>
					<td><center>Fecha Vehículo</center></td>
					<td><center>Peso</center></td>
					<td><center>Descripcion</center></td>
					<td><center>Sucursal</center></td>

				</thead>

				<?php $__currentLoopData = $maritimos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maritimo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($maritimo->codigo); ?></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><?php echo e($maritimo->capacidad_carga); ?></td>
					<td><?php echo e($maritimo->serial_motor); ?></td>
					<td><center><?php echo e($maritimo->matricula); ?></center></td>
					<td><?php echo e($maritimo->marca); ?></td>
					<td><?php echo e($maritimo->modelo); ?></td>
					<td><?php echo e($maritimo->fecha_vehiculo); ?></td>
					<td><?php echo e($maritimo->peso); ?></td>
					<td><?php echo e($maritimo->descripcion); ?></td>
					<td><?php echo e($maritimo->sucursal); ?></td>
					<td>
						<td><a href="<?php echo e(URL::action('MaritimoController@edit',$maritimo->codigo)); ?>"><button class="btn btn-info">Editar</button></a></td>
						<td><a href="" data-target="#modal-delete-<?php echo e($maritimo->codigo); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a></td>
					</td>
				</tr>
				<?php echo $__env->make('transporte.maritimo.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($maritimos->render()); ?>


			<h4>Transportes mas utilizados</h2>
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>Numero de veces utilizado</td>
					<td>Codigo del transporte</td>
				</thead>

				<?php $__currentLoopData = $usados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($us->numero); ?></td>
					<td><?php echo e($us->codigo_del_transporte); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>