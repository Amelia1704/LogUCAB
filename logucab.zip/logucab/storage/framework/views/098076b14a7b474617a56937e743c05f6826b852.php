<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
	<h3>Empleados LogUCAB <a href="lista/create"><button class="btn btn-success">Nuevo</button></a></h3>
	<?php echo $__env->make('empleado.nomina.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<td>ID</td>
					<td>Cédula</td>
					<td>Nombre</td>
					<td>Apellido</td>
					<td>Email Personal</td>
					<td>Email Empresa</td>
					<td>Fecha de nacimiento</td>
					<td>Nivel Académico</td>
					<td>Profesión</td>
					<td>Estado Civil</td>
					<td>Número de Hijos</td>
					<td>Fecha Ingreso</td>
					<td>Activo</td>
					<td>Fecha Egreso</td>
					<td>Dirección</td>
					<td>Salario</td>
					<td>Opciones</td>
				</thead>

				<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($emp->id); ?></td> 
					<!-- se utiliza llave llave para mostrar texto en laravel -->
					<td><?php echo e($emp->cedula); ?></td>
					<td><?php echo e($emp->nombre); ?></td>
					<td><?php echo e($emp->apellido); ?></td>
					<td><?php echo e($emp->email_personal); ?></td>
					<td><?php echo e($emp->email_empresa); ?></td>
					<td><?php echo e($emp->fecha_nac); ?></td>
					<td><?php echo e($emp->nivel_academico); ?></td>
					<td><?php echo e($emp->profesion); ?></td>
					<td><?php echo e($emp->estado_civil); ?></td>
					<td><?php echo e($emp->numero_hijos); ?></td>
					<td><?php echo e($emp->salario); ?></td>
					<td><?php echo e($emp->fecha_ingreso); ?></td>
					<td><?php echo e($emp->activo); ?></td>
					<td><?php echo e($emp->fecha_egreso); ?></td>
					<td><?php echo e($emp->lugar); ?></td>

					<td>
						<a href="<?php echo e(URL::action('EmpleadoController@edit',$emp->id)); ?>"><button class="btn btn-info">Editar</button></a>
						<a href="" data-target="#modal-delete-<?php echo e($emp->id); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
					</td>
				</tr>
				<?php echo $__env->make('empleado.nomina.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($empleados->render()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>