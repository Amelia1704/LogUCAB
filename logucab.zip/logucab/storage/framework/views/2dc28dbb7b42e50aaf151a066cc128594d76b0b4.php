<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar nueva ruta</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'ruta/mostrar', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>


		<div class="form-group">
			<label for="origen">Origen</label>
					<select name="fk_sucursal_origen" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>
		<div class="form-group">
			<label for="destino">Destino</label>
					<select name="fk_sucursal_destino" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>
		<div class="form-group">
			<label for="costo">Costo</label>
			<input type="text" name="costo" class="form-control" placeholder="Costo">	
		</div>
		<div class="form-group">
			<label for="duracion">Duración (mins)</label>
			<input type="text" name="duracion" class="form-control" placeholder="Duración">	
		</div>			
		<div class="form-group">
			<label for="transporte">Medio de Transporte</label>
			<select name="transporte" class="form-control">
				<option value="Terrestre">Terrestre</option>
				<option value="Marítimo">Marítimo</option>
				<option value="Aéreo">Aéreo</option>
			</select>	
		</div>

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>