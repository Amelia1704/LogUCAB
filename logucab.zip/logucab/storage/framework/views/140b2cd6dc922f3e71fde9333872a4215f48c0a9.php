<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Ruta: <?php echo e($ruta->id); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::model($ruta,['method'=>'PATCH', 'route'=>['mostrar.update', $ruta->id]]); ?>

		<?php echo e(Form::token()); ?>

		<div class="form-group">
			<label for="origen">Origen</label>
					<select name="fk_sucursal_origen" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($suc->codigo==$ruta->fk_sucursal_origen): ?>
						<option value="<?php echo e($suc->codigo); ?>" selected><?php echo e($suc->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>	
		<div class="form-group">
			<label for="destino">Destino</label>
					<select name="fk_sucursal_destino" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($suc->codigo==$ruta->fk_sucursal_origen): ?>
						<option value="<?php echo e($suc->codigo); ?>" selected><?php echo e($suc->nombre); ?></option><?php else: ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>	
		</div>
		<div class="form-group">
			<label for="costo">Costo</label>
			<input type="text" name="costo" required value="<?php echo e($ruta->costo); ?>" class="form-control">
		</div>
		<div class="form-group">
			<label for="duracion">Duración</label>
			<input type="text" name="duracion" required value="<?php echo e($ruta->duracion); ?>" class="form-control">
		</div>

		<div class="form-group">
			<a href="<?php echo e(URL::action('RutaController@index')); ?>"><button class="btn btn-primary" type="submit">Guardar</button></a>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>