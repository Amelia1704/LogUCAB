
<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<div class="table-responsive">

			<h3>Registrar un nuevo vehículo</h3>
			<?php if(count($errors)>0): ?>
			<div class="aler alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>				
			</div>
		<?php endif; ?>



		<?php echo Form::open(array('url'=>'transporte/terrestre', 'method'=>'POST', 'autocomplete'=>'off')); ?>

		<?php echo e(Form::token()); ?>



		</div>	
		<div class="form-group">
			<label for="capacidad_carga">Capacidad carga (m2)</label>
			<input type="text" name="capacidad_carga" class="form-control" placeholder="Capacidad carga">	
		</div>
		<div class="form-group">
			<label for="serial_motor">Serial motor</label>
			<input type="text" name="serial_motor" class="form-control" placeholder="Serial motor">	
		</div>	
		<div class="form-group">
			<label for="matricula">Matrícula</label>
			<input type="text" name="matricula" class="form-control" placeholder="Matricula">	
		</div>	
		<div class="form-group">
			<label for="marca">Marca</label>
			<input type="text" name="marca" class="form-control" placeholder="Marca">	
		</div>	
		<div class="form-group">
			<label for="modelo">Modelo</label>
			<input type="text" name="modelo" class="form-control" placeholder="Modelo">	
		</div>		
		<div class="form-group">
			<label for="fecha_vehiculo">Fecha Vehículo</label>
			<input type="date" name="fecha_vehiculo" class="form-control" placeholder="Fecha vehiculo">	
		</div>
		<div class="form-group">
			<label for="serial_carroceria">Serial Carrocería</label>
			<input type="text" name="serial_carroceria" class="form-control" placeholder="Serial Carroceria">	
		</div>	
		<div class="form-group">
			<label for="tipo">Tipo</label>
			<select name="tipo" class="form-control">
				<option value="Camion">Camion</option>
				<option value="Motocicleta">Motocicleta</option>
			</select>	
		</div>	
		<div class="form-group">
			<label for="sucursal">Sucursal</label>
					<select name="fk_sucursal" class="form-control">
						<?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($suc->codigo); ?>"><?php echo e($suc->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>					
		</div>	

		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Borrar</button>
			
		</div>

			<?php echo Form::close(); ?>


		</div>
	  			</div>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>